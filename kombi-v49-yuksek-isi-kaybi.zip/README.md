# Kombi Kontrol V49 (Android)

## V49 (yüksek ısı kayıplı ev döngü profili)
- Döngü modunun yeni kurulum varsayılan profilleri, yalıtımsız/en üst kat gibi ısı kaybı yüksek evlerde daha kısa kapalı aralıklar için güncellendi.
- Döngü kartındaki sabit “40°C” metni kaldırıldı; kombi su sıcaklığının kombiden ayarlandığı belirtildi.
- Döngü ekranına oda sıcaklığı ölçülmediği ve gaz tasarrufunun garanti edilmediği uyarısı eklendi.
- Mevcut kullanıcı ayarları/localStorage korunur; güncelleme kayıtlı döngü sürelerini kendiliğinden değiştirmez. Yeni profili kullanmak için ilgili hava bandına yeniden dokunarak varsayılan süreleri yükleyin.
- `versionCode` 49.


HTML arayüz (`app/src/main/assets/index.html`) WebView içinde açılır; Kotlin tarafı eWeLink ile konuşur.
Derleme ve eWeLink kurulumu için V13 README'sindeki adımlar aynen geçerli (GitHub Secrets: `EWELINK_APP_ID`, `EWELINK_APP_SECRET`).

## V48 (İstatistik sekmesi yenilendi)
- Sade yeni düzen: Bugün / 7 / 30 gün özeti (animasyonlu sayaç), tek günlük grafik (ısınma + sürekli yanma çubukları, dış sıcaklık çizgisi, dokununca gün ayrıntısı), açılış analizi, hava-gaz eğilimi ve gösterge.
- **Açılış analizi**: soğuk/ılık/sıcak açılış sayısı, ısınma yüzünden fazladan yanan gaz (m³, ₺, %), erken kapanan açılışlar. Soğuk açılış ısınma süresi Hesap ayarları'ndan değişir.
- **Hava ile gaz**: 30 günlük dağılım grafiği ve eğilim çizgisi ("1°C soğuyunca +x m³"), önümüzdeki 6 gün için tahmini gaz. Hava verisi 30 gün geriye alınır ve günlük ortalamalar telefonda saklanır.
- Gösterge: kullanım verisi olmayan günler artık "tasarruf" sayılmaz; kendi verinden derece-gün katsayısı önerilir.
- Düzeltmeler: gece yarısını aşan çalışmanın gazı artık günlere bölünür (süreyle uyumlu); özet kutuları takvim gününe göre; hava verisi gelince sekme yenilenir. `versionCode` 48.

## V46 (telefon alarmı, kararlı sürüm)
- Röle içi zamanlayıcı kodu (DeviceTimers) tamamen kaldırıldı; cihaz bunu desteklemiyor. Sürekli arka plan servisi de yok.
- Zamanlama yalnızca telefon alarmlarıyla (sistem saat alarmı, setAlarmClock) çalışır; alarm anında kısa komut servisi, yeniden deneme alarmı, bekçi ve uygulama açılınca plana uydurma devam eder.
- Teşhis: alarm gelince ilk iş "Alarm alındı" kaydı düşer (silinmiş kayıt ya da hata da yazılır); zamanlamalar kurulunca "N alarm kuruldu, ilk alarm: saat" kaydı düşer.

## V45
- Sürekli açık duran arka plan servisi ve "Kombi planı etkin" bildirimi kaldırıldı. Alarm anındaki kısa komut servisi (V40) kalır.

## V44
- **Arka planda canlı tutma** (`KeepAliveService`): aktif zamanlama/döngü varken sessiz bir ön plan servisi çalışır (bildirim: "Kombi planı etkin"). Uygulama son uygulamalardan kaydırılınca Android süreci ve alarmları öldürmez. Röle içi zamanlayıcı yazımı (eWeLink 4002 verdi) devre dışı bırakıldı.

## V43
- Röle zamanlayıcı yazımı cihaz 4002 verirse azalan sayıda ve alternatif biçimle yeniden dener; yine olmazsa hata kaydına cihazdaki mevcut zamanlayıcıları da yazar (teşhis).

## V42 değişiklikleri
- **Röle içi yedek zamanlayıcı** (`DeviceTimers`): zamanlamadaki yaklaşan (24 saat içinde, en çok 8) AÇ/KAPAT olayı rölenin kendi saatine tek seferlik zamanlayıcı olarak yazılır. Uygulama kapalı / telefon uykuda / alarm silinmiş olsa bile röle bunları kendi başına uygular. Pencere her uygulama açılışında, alarmda ve 15 dk'lık bekçide ileri kayar. Sadece bu uygulamanın yazdığı zamanlayıcılar değiştirilir. Sonuç "Son işlemler"de "röle zamanlayıcı" olarak görünür.
- **Otomatik seçim**: döngü bandı artık önümüzdeki 6 saatin ortalama sıcaklığına göre seçilir (gündüz/gece ayrımı kalktı): <0 çok soğuk, 0–6 soğuk, 6–12 serin, 12+ ılık. `versionCode` 42.

## V41 değişiklikleri
- **Tüm alarmlar `setAlarmClock` ile kurulur** (sistem saat alarmı): uyku modu ve marka pil kısıtlamalarından muaf, telefon kilitliyken ve uygulama kapalıyken de tetiklenir. Yan etki: durum çubuğunda alarm simgesi görünür. `versionCode` 41.

## V40 değişiklikleri (kilitli telefonda döngü planı çalışmıyordu)
- **Sebep**: Telefon kilitli/uyku (Doze) modundayken alarm tetikleniyor ama arka plandaki uygulamanın interneti kapalı oluyordu. 8 sn'lik hızlı deneme başarısız oluyor, yedek WorkManager işi uykuda ertelenip bir sonraki döngü alarmıyla iptal ediliyordu; sonuç: komut hiç gitmiyordu.
- **Alarm → kısa ön plan servisi** (`CommandService`, shortService + wakelock): alarm anında servis ağ ve CPU alır, komut doğrulanana dek ~1 dk denenir. Olmazsa 90 sn sonra **yeniden deneme alarmı** (`CommandRetryReceiver`) kurulur; 15 dk'lık bekçi de doğrulanmamış komutu yeniden dener.
- **Uygulama açılınca otomatik plana uyar**: kombi planla uyuşmuyorsa ("Şimdi plana uydur" beklemeden) komut kendiliğinden gönderilir. Plan saatinden sonra elle müdahale ettiysen veya zamanlayıcı çalışıyorsa dokunmaz.
- Döngü olayları için kaçırılan zamanlama telafisi 30 dk'dan 3 saate çıkarıldı.
- Elle/plana uydur komutu ağ hatasında otomatik 1 kez daha denenir.
- Yeni izinler: `FOREGROUND_SERVICE`, `WAKE_LOCK`. `versionCode` 40.

## V25 değişiklikleri
- **Saat gecikmesi düzeltildi**: ana ekrandaki saat 30 saniyede bir güncelleniyordu, bu yüzden dakika değişimini yarım dakikaya kadar geç gösteriyordu. Artık saniyede bir kontrol edilir; dakika değişince hemen güncellenir (telefon saatiyle aynı).
- **Fatura hesaplayıcı** (İstatistik kartındaki "🧾 Fatura Hesapla" düğmesi veya Ayarlar > İstatistik ve Gaz Fiyatı): ilk/son endeks, düzeltme katsayısı, üst ısıl değer, birim fiyat, KDV, diğer bedeller, gecikme ve yuvarlama girilerek m³ → kWh → tüketim bedeli → KDV → ödenecek tutar hesaplanır. İlk açılışta son fatura (21.09–20.10.2026) örnek olarak yüklü gelir.
- **Ortalama fatura**: faturalar kaydedilebilir (en fazla 36); kayıtlı faturaların ortalama tutarı/tüketimi ve günlük ortalamaya göre **30 günlük tahmini fatura** gösterilir. Fiyat veya KDV değişince tahmin anında güncellenir. Kayıtlar Android yedeğine dahildir.
- **Üstteki "Kombi Kontrol" şeridi kaldırıldı**: V24'te tema DayNight'a geçince Android'in başlık çubuğu (action bar) görünmeye başlamıştı; kapatıldı, uygulama yine tam ekran açılır.
- **5 dk adımlı süre ayarı**: zamanlayıcı düğmelerinin altında − / + (5 dk) ve ▶ Başlat. Zamanlayıcı çalışırken − / + kalan süreyi 5 dk artırır/azaltır (en az 1 dk kalmalı, en fazla 4 saat).
- **30 günlük istatistik**: "Son 30 Gün Toplam" (çalışma süresi) ve "30 Gün Tahmini Gaz" (m³ · ₺) eklendi; fatura aylık geldiği için aylık tüketimi görmek içindir. (Kayıtlar zaten 40 gün tutuluyordu.)
- `versionCode` 25.

## V24 değişiklikleri
- **Sistem temasını takip et düzeltildi**: uygulama teması her zaman koyu olduğu için WebView sistem temasını hep "karanlık" bildiriyordu. Tema artık DayNight; ayrıca sistem teması doğrudan Android'den okunur ve tema değişince arayüz anında güncellenir.
- **Mobil veride komut gitmeme**: bağlantı artık doğrudan aktif ağa (mobil veri/Wi-Fi) bağlanır (eski bağlantı havuzu kullanılmaz), `Connection: close`, ağ hatasında otomatik 1 yeniden deneme. Hata artık anlaşılır yazılır: "İnternet bağlantı hatası (mobil veri): zaman aşımı / DNS ..." — hâlâ olursa bu mesajı bildir.

## V23 değişiklikleri
- **Sesli konuşma kaldırıldı**: kombi devreye girince/çıkınca normal telefon bildirimi gelir (varsayılan bildirim sesi; ses ve izin Ayarlar > Bildirim ayarları'ndan değiştirilebilir). Android 13+ ilk açılışta bildirim izni sorar.
- **Android 10+ (minSdk 29)**, hızlı açılış (şifreli depo ve WorkManager arka planda başlar), arka plana geçince WebView durur, animasyonlar hafifletildi (bulanıklık efekti yok, daha az parçacık, ekran kapalıyken animasyon durur), hata ayıklama yükü kapalı.
- **Ayar/istatistik güvenliği**: tüm veriler uygulamanın özel alanında tutulur (dosya yöneticisinden görünmez, silinemez; yalnızca "Verileri temizle"/kaldırma siler). Ayrıca zamanlamalar, tatil modu, tema, gaz fiyatı ve istatistik yedeği Android Yedekleme'ye dahildir; WebView verisi silinirse otomatik geri yüklenir. eWeLink token'ları yedeğe girmez (yeniden giriş gerekir).
- **Üzerine güncelleme**: sabit imza anahtarı (`app/kombi-key.p12`) eklendi; her GitHub derlemesi aynı anahtarla imzalanır, `versionCode` 23. Anahtarı silme/değiştirme, repo'yu özel (private) tut.

> İlk geçişte: V22 ve öncesi her derlemede rastgele imza kullanıldığı için bu sürümü kurmadan önce eski uygulamayı **bir kez** kaldırmak gerekir. Bundan sonraki tüm sürümler üzerine güncellenir.

## V22 değişiklikleri
- **Hava durumuna bağlı animasyonlar**: dalgalanan ışık kaldırıldı; kart artık havaya göre değişir (güneşli: ışınlar, gece: yıldız + kayan yıldız, bulutlu/parçalı: süzülen bulutlar, yağmur, kar, sis, fırtına: yağmur + şimşek). Aydınlık/karanlık temaya uyumlu.
- **Ayarlar > İstatistik ve Gaz Fiyatı**: "İstatistikleri Sıfırla" (iki dokunuşla onay) ve doğalgaz birim fiyatı (₺/kWh) güncelleme.
- **İstatistikler uygulama kapalıyken de kaydedilir**: telefon alarmı/komutu ile biten her çalışma Kotlin tarafında kaydedilir, uygulama açılınca istatistiğe eklenir (çift sayım engellenir). Ayrıca istatistik + fiyat yedeği telefonda tutulur.
- **"Cihaz Bilgisini Göster" kaldırıldı** (hata veriyordu).
- **eWeLink girişinden sonra cihazlar otomatik listelenir**, kayıtlı ID hesapta yoksa çevrimiçi ilk cihazın ID'si otomatik yazılır/kaydedilir.

## V21 değişiklikleri (zamanlama güvenilirliği)
- **Tam zamanlı alarm izni**: `SCHEDULE_EXACT_ALARM` (Android 12/12L) + `USE_EXACT_ALARM` (Android 13+). İzin yoksa Ayarlar > Arka Plan Durumu'nda uyarı çıkar.
- **Alarm zinciri kopmaz**: her alarm, komuttan ÖNCE bir sonrakini kurar.
- **Doğrulanmış komut**: röleye komut gönderildikten sonra durum cihazdan geri okunur; sadece doğrulanırsa başarılı sayılır ve sesli duyuru yapılır.
- **WorkManager**: alarm anında hızlı deneme (4 sn) yapılır; başarısızsa ya da süreç öldürülürse kalıcı iş ağ gelince 30 sn aralıklarla yeniden dener (kapatma 3 saat, açma 90 dk boyunca).
- **Bekçi (15 dk)**: silinmiş alarmları yeniden kurar, kaçırılan zamanlamayı (30 dk içinde) telafi eder, gecikmiş kapanmayı yeniden gönderir.
- **Reboot / güncelleme / saat değişimi / izin değişimi** sonrası alarmlar yeniden kurulur.
- **4 saat güvenlik kapatması** artık zamanlamayla açılan kombi için de telefonda kurulur; zamanlama OFF'u eski kapanma alarmını iptal eder.
- **Tek doğru kaynak**: cihaz içi (bulut) zamanlayıcılar kullanılmaz; önceki sürümlerin yazdığı zamanlayıcılar cihazdan bir kez silinir (telefon komutlarıyla çakışıp röleyi geri kapatmasın).
- **Token yarışı** giderildi (taze token okuma, süreç geneli yenileme kilidi, oturum silmeden önce yeniden deneme).
- **TTS**: `<queries>` eklendi (Android 11+), zaman aşımı korumalı.
- **Son işlemler**: Ayarlar > Arka Plan Durumu'nda her alarm/komut/yeniden deneme kaydı görünür.

## Kurulumdan sonra (önemli)
1. Uygulamayı bir kez aç (alarmlar kurulur). Ayarlar > Arka Plan Durumu'nda iki işaret de ✅ olmalı.
2. "Tam zamanlı alarm iznini aç" ve "Pil optimizasyonunu kapat" butonlarına bas.
3. Xiaomi/Huawei/Oppo/Samsung'ta: Uygulama ayarları > Otomatik başlatma AÇIK, pil: "Kısıtlama yok".
4. Uygulamayı son uygulamalardan kaydırarak kapatmak sorun değil; "Zorla durdur" yaparsan Android tüm alarmları siler, uygulamayı bir kez açman gerekir.
5. Telefon sessiz/Rahatsız Etmeyin modundaysa sesli duyuru duyulmaz (komut yine de çalışır).
