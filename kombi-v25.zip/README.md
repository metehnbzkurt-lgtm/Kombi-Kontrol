# Kombi Kontrol V25 (Android)

HTML arayüz (`app/src/main/assets/index.html`) WebView içinde açılır; Kotlin tarafı eWeLink ile konuşur.
Derleme ve eWeLink kurulumu için V13 README'sindeki adımlar aynen geçerli (GitHub Secrets: `EWELINK_APP_ID`, `EWELINK_APP_SECRET`).

## V25 değişiklikleri
- **Saat gecikmesi düzeltildi**: ana ekrandaki saat 30 saniyede bir güncelleniyordu, bu yüzden dakika değişimini yarım dakikaya kadar geç gösteriyordu. Artık saniyede bir kontrol edilir; dakika değişince hemen güncellenir (telefon saatiyle aynı).
- **Fatura hesaplayıcı** (İstatistik kartındaki "🧾 Fatura Hesapla" düğmesi veya Ayarlar > İstatistik ve Gaz Fiyatı): ilk/son endeks, düzeltme katsayısı, üst ısıl değer, birim fiyat, KDV, diğer bedeller, gecikme ve yuvarlama girilerek m³ → kWh → tüketim bedeli → KDV → ödenecek tutar hesaplanır. İlk açılışta son fatura (21.09–20.10.2026) örnek olarak yüklü gelir.
- **Ortalama fatura**: faturalar kaydedilebilir (en fazla 36); kayıtlı faturaların ortalama tutarı/tüketimi ve günlük ortalamaya göre **30 günlük tahmini fatura** gösterilir. Fiyat veya KDV değişince tahmin anında güncellenir. Kayıtlar Android yedeğine dahildir.
- `versionCode` 25.

## V24 değişiklikleri
- **Sistem temasını takip et düzeltildi**: uygulama teması her zaman koyu olduğu için WebView sistem temasını hep "karanlık" bildiriyordu. Tema artık DayNight; ayrıca sistem teması doğrudan Android'den okunur ve tema değişince arayüz anında güncellenir.
- **Mobil veride komut gitmeme**: bağlantı artık doğrudan aktif ağa (mobil veri/Wi-Fi) bağlanır (eski bağlantı havuzu kullanılmaz), `Connection: close`, ağ hatasında otomatik 1 yeniden deneme. Hata artık anlaşılır yazılır: "İnternet bağlantı hatası (mobil veri): zaman aşımı / DNS ..." — hâlâ olursa bu mesajı bildir.

## V23 değişiklikleri
- **Sesli konuşma kaldırıldı**: kombi devreye girince/çıkınca normal telefon bildirimi gelir (varsayılan bildirim sesi; ses ve izin Ayarlar > Bildirim ayarları'ndan değiştirilebilir). Android 13+ ilk açılışta bildirim izni sorar.
- **Android 10+ (minSdk 29)**, hızlı açılış (şifreli depo ve WorkManager arka planda başlar), arka plana geçince WebView durur, animasyonlar hafifletildi (bulanıklık efekti yok, daha az parçacık, ekran kapalıyken animasyon durur), hata ayıklama yükü kapalı.
- **Ayar/istatistik güvenliği**: tüm veriler uygulamanın özel alanında tutulur (dosya yöneticisinden görünmez, silinemez; yalnızca "Verileri temizle"/kaldırma siler). Ayrıca zamanlamalar, tatil modu, tema, gaz fiyatı ve istatistik yedeği Android Yedekleme'ye dahildir; WebView verisi silinirse otomatik geri yüklenir. eWeLink token'ları yedeğe girmez (yeniden giriş gerekir).
- **Üzerine güncelleme**: sabit imza anahtarı (`app/kombi-key.p12`) eklendi; her GitHub derlemesi aynı anahtarla imzalanır, `versionCode` 23. Anahtarı silme/değiştirme, repo'yu özel (private) tut.

> İlk geçişte: V22 ve öncesi her derlemede rastgele imza kullanıldığı için bu sürümü kurmadan önce eski uygulamayı **bir kez** kaldırmak gerekir. Bundan sonraki tüm sürümler üzerine güncellenir.

## V22 değişiklikleri
- **Hava durumuna bağlı animasyonlar**: dalgalanan ışık kaldırıldı; kart artık havaya göre değişir (güneşli: ışınlar, gece: yıldız + kayan yıldız, bulutlu/parçalı: süzülen bulutlar, yağmur, kar, sis, fırtına: yağmur + şimşek). Aydınlık/karanlık temaya uyumlu.
- **Ayarlar > İstatistik ve Gaz Fiyatı**: "İstatistikleri Sıfırla" (iki dokunuşla onay) ve doğalgaz birim fiyatı (₺/kWh) güncelleme.
- **İstatistikler uygulama kapalıyken de kaydedilir**: telefon alarmı/komutu ile biten her çalışma Kotlin tarafında kaydedilir, uygulama açılınca istatistiğe eklenir (çift sayım engellenir). Ayrıca istatistik + fiyat yedeği telefonda tutulur.
- **"Cihaz Bilgisini Göster" kaldırıldı** (hata veriyordu).
- **eWeLink girişinden sonra cihazlar otomatik listelenir**, kayıtlı ID hesapta yoksa çevrimiçi ilk cihazın ID'si otomatik yazılır/kaydedilir.

## V21 değişiklikleri (zamanlama güvenilirliği)
- **Tam zamanlı alarm izni**: `SCHEDULE_EXACT_ALARM` (Android 12/12L) + `USE_EXACT_ALARM` (Android 13+). İzin yoksa Ayarlar > Arka Plan Durumu'nda uyarı çıkar.
- **Alarm zinciri kopmaz**: her alarm, komuttan ÖNCE bir sonrakini kurar.
- **Doğrulanmış komut**: röleye komut gönderildikten sonra durum cihazdan geri okunur; sadece doğrulanırsa başarılı sayılır ve sesli duyuru yapılır.
- **WorkManager**: alarm anında hızlı deneme (4 sn) yapılır; başarısızsa ya da süreç öldürülürse kalıcı iş ağ gelince 30 sn aralıklarla yeniden dener (kapatma 3 saat, açma 90 dk boyunca).
- **Bekçi (15 dk)**: silinmiş alarmları yeniden kurar, kaçırılan zamanlamayı (30 dk içinde) telafi eder, gecikmiş kapanmayı yeniden gönderir.
- **Reboot / güncelleme / saat değişimi / izin değişimi** sonrası alarmlar yeniden kurulur.
- **4 saat güvenlik kapatması** artık zamanlamayla açılan kombi için de telefonda kurulur; zamanlama OFF'u eski kapanma alarmını iptal eder.
- **Tek doğru kaynak**: cihaz içi (bulut) zamanlayıcılar kullanılmaz; önceki sürümlerin yazdığı zamanlayıcılar cihazdan bir kez silinir (telefon komutlarıyla çakışıp röleyi geri kapatmasın).
- **Token yarışı** giderildi (taze token okuma, süreç geneli yenileme kilidi, oturum silmeden önce yeniden deneme).
- **TTS**: `<queries>` eklendi (Android 11+), zaman aşımı korumalı.
- **Son işlemler**: Ayarlar > Arka Plan Durumu'nda her alarm/komut/yeniden deneme kaydı görünür.

## Kurulumdan sonra (önemli)
1. Uygulamayı bir kez aç (alarmlar kurulur). Ayarlar > Arka Plan Durumu'nda iki işaret de ✅ olmalı.
2. "Tam zamanlı alarm iznini aç" ve "Pil optimizasyonunu kapat" butonlarına bas.
3. Xiaomi/Huawei/Oppo/Samsung'ta: Uygulama ayarları > Otomatik başlatma AÇIK, pil: "Kısıtlama yok".
4. Uygulamayı son uygulamalardan kaydırarak kapatmak sorun değil; "Zorla durdur" yaparsan Android tüm alarmları siler, uygulamayı bir kez açman gerekir.
5. Telefon sessiz/Rahatsız Etmeyin modundaysa sesli duyuru duyulmaz (komut yine de çalışır).
