package com.kombikontrol.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader

class MainActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var bridge: KombiBridge

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Ağır başlatmalar (şifreli depo, WorkManager) arka planda: arayüz hemen açılır.
        val appCtx = applicationContext
        Thread {
            try { SecureStore.get(appCtx) } catch (_: Throwable) {}
            try { WatchdogWorker.enqueue(appCtx) } catch (_: Throwable) {}
        }.start()

        // Android 13+: bildirim izni (kombi çalıştı/durdu bildirimi için)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
        }

        web = WebView(this)
        web.overScrollMode = View.OVER_SCROLL_NEVER
        web.isVerticalScrollBarEnabled = false
        val sysDark = (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES
        web.setBackgroundColor(if (sysDark) 0xFF06090F.toInt() else 0xFFEEF1F7.toInt())
        setContentView(web)

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? = loader.shouldInterceptRequest(request.url)
        }

        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = false
        }

        bridge = KombiBridge(this, web)
        web.addJavascriptInterface(bridge, "KombiNative")
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")

        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    /** eWeLink giriş sayfasından "kombikontrol://oauth/callback?code=..." ile buraya döner. */
    private fun handleIntent(intent: Intent?) {
        val uri = intent?.data ?: return
        if (uri.scheme == "kombikontrol" && uri.host == "oauth") {
            bridge.handleOAuthRedirect(uri)
        }
    }

    /** Sistem teması (aydınlık/karanlık) değişince arayüze haber ver (uiMode configChanges'te olduğu için yeniden oluşturma yok). */
    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        web.evaluateJavascript("window.onSystemThemeChanged && window.onSystemThemeChanged()", null)
    }

    override fun onPause() {
        super.onPause()
        web.onPause()      // arka planda WebView zamanlayıcı/animasyon yükü yok (alarmlar zaten telefon tarafında)
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
        web.evaluateJavascript("window.onNativeResume && window.onNativeResume()", null)
    }
}
