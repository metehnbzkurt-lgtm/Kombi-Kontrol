package com.kombikontrol.app

import android.content.BroadcastReceiver
import android.content.Context
import android.os.Handler
import android.os.Looper
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Alarm alıcılarından (ScheduleReceiver, AutoOffReceiver) gelen komutu yürütür.
 *
 * Sıra önemli:
 *  1) Güvenlik ağı: önce WorkManager işi kuyruğa alınır (süreç öldürülse bile komut kaybolmaz).
 *  2) Hızlı deneme (kısa zaman aşımı) alıcının kısa süresi içinde yapılır.
 *  3) Başarılıysa güvenlik ağı iptal edilir; başarısızsa WorkManager hemen yeniden dener.
 */
object CommandDispatcher {

    fun fromReceiver(app: Context, on: Boolean, origin: String, pending: BroadcastReceiver.PendingResult) {
        val seq = CommandRunner.nextSeq(app)
        val at = System.currentTimeMillis()
        CommandWorker.enqueue(app, on, seq, at, origin, delaySec = 25)

        val done = AtomicBoolean(false)
        fun finish() {
            if (done.compareAndSet(false, true)) {
                try { pending.finish() } catch (_: Exception) {}
            }
        }
        // Android alarm yayınında yaklaşık 10 sn izin verir; önce biz bırakalım.
        Handler(Looper.getMainLooper()).postDelayed({ finish() }, 8000L)

        Thread {
            try {
                val o = CommandRunner.run(app, on, origin, fast = true, seq = seq)
                if (o.ok) {
                    if (CommandRunner.currentSeq(app) == seq) CommandWorker.cancel(app)
                    Notifier.announce(app, on)
                    finish()
                } else {
                    if (CommandRunner.currentSeq(app) == seq) CommandWorker.enqueue(app, on, seq, at, origin, delaySec = 0)
                    finish()
                }
            } catch (_: Throwable) {
                finish()
            }
        }.start()
    }
}
