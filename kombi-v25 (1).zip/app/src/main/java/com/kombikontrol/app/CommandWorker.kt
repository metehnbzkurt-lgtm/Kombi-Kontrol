package com.kombikontrol.app

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequest
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/**
 * Kalıcı (reboot'a dayanıklı) komut işi: ağ varken komutu gönderir, başarısız olursa
 * doğrusal geri çekilmeyle yeniden dener. Alarm anındaki hızlı deneme başarısız olursa
 * ya da süreç öldürülürse devreye girer.
 */
class CommandWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {

    override fun doWork(): Result {
        val app = applicationContext
        val on = inputData.getBoolean("on", true)
        val seq = inputData.getLong("seq", 0L)
        val at = inputData.getLong("at", 0L)
        val origin = inputData.getString("origin") ?: "arka plan"
        val p = app.getSharedPreferences("kombi", Context.MODE_PRIVATE)

        // Daha yeni bir komut geldiyse bu eski komutu uygulama.
        if (seq > 0 && CommandRunner.currentSeq(app) != seq) return Result.success()
        // Hızlı yol zaten başardıysa tekrar etme.
        if (seq > 0 && p.getLong("lastOkSeq", -1L) == seq) return Result.success()

        val maxAge = if (on) 90 * 60_000L else 3 * 60 * 60_000L
        if (System.currentTimeMillis() - at > maxAge) {
            ActionLog.add(app, origin, on, false, "Vazgeçildi: komut ${maxAge / 60000} dk içinde uygulanamadı")
            Notifier.failure(app, "Kombi komutu uygulanamadı")
            return Result.success()
        }

        val o = CommandRunner.run(app, on, "$origin (deneme ${runAttemptCount + 1})", fast = false, seq = seq)
        return if (o.ok) {
            Notifier.announce(app, on)
            Result.success()
        } else {
            Result.retry()
        }
    }

    companion object {
        private const val UNIQUE = "kombi-cmd"

        fun enqueue(app: Context, on: Boolean, seq: Long, at: Long, origin: String, delaySec: Long) {
            val data = Data.Builder()
                .putBoolean("on", on)
                .putLong("seq", seq)
                .putLong("at", at)
                .putString("origin", origin)
                .build()
            val builder = OneTimeWorkRequest.Builder(CommandWorker::class.java)
                .setInputData(data)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .setBackoffCriteria(BackoffPolicy.LINEAR, 30, TimeUnit.SECONDS)
            if (delaySec > 0) builder.setInitialDelay(delaySec, TimeUnit.SECONDS)
            WorkManager.getInstance(app.applicationContext)
                .enqueueUniqueWork(UNIQUE, ExistingWorkPolicy.REPLACE, builder.build())
        }

        fun cancel(app: Context) {
            WorkManager.getInstance(app.applicationContext).cancelUniqueWork(UNIQUE)
        }
    }
}
