package com.kombikontrol.app

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * eWeLink (CoolKit) v2 REST istemcisi — OAuth2.0.
 * NOT: Developer onayı olmadan test edilemedi; imzalama (sign) adımı dokümantasyona göre
 * yazıldı, gerçek App ID/Secret gelince doğrulanması/düzeltilmesi gerekebilir.
 * Resmi dokümantasyon: https://coolkit-technologies.github.io/eWeLink-API/#/en/OAuth2.0
 *
 * Email/şifre bu sınıfta YOK. Kullanıcı eWeLink'in kendi tarayıcı sayfasında giriş yapar,
 * buraya sadece dönen "authorization code" gelir, o da token'a çevrilir.
 */
class EweLinkClient(private val appId: String, private val appSecret: String) {

    class AuthException(msg: String) : Exception(msg)

    companion object {
        /** Uygulama + arka plan aynı anda token yenilemesin diye süreç geneli kilit. */
        private val REFRESH_LOCK = Any()
    }

    /** Aktif ağı (mobil veri / Wi-Fi) bulmak için. */
    var context: Context? = null

    /** HTTP zaman aşımı (ms). Alarm anında kısa (4 sn), uygulama içinde uzun. */
    var timeoutMs: Int = 15000

    var region: String = "eu"
    var accessToken: String? = null
    var refreshToken: String? = null

    val configured: Boolean get() = appId.isNotEmpty() && appSecret.isNotEmpty()

    private fun sign(body: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(appSecret.toByteArray(), "HmacSHA256"))
        return Base64.encodeToString(mac.doFinal(body.toByteArray()), Base64.NO_WRAP)
    }

    /** Tarayıcıda açılacak eWeLink giriş sayfası adresi. */
    fun buildAuthorizeUrl(redirectUrl: String, state: String): String {
        val seq = System.currentTimeMillis().toString()
        val nonce = UUID.randomUUID().toString().replace("-", "").take(8)
        // Resmi dokuman: yetkilendirme sayfasi imzasi = HMAC-SHA256("{clientId}_{seq}") base64
        val authorization = sign("${appId}_$seq")
        val params = listOf(
            "state" to state,
            "clientId" to appId,
            "authorization" to authorization,
            "seq" to seq,
            "redirectUrl" to redirectUrl,
            "grantType" to "authorization_code",
            "nonce" to nonce
        ).joinToString("&") { (k, v) -> "$k=" + java.net.URLEncoder.encode(v, "UTF-8") }
        return "https://c2ccdn.coolkit.cc/oauth/index.html?$params"
    }

    /** Bağlantı hatasını kullanıcıya anlamlı söyler (hangi ağda, ne oldu). */
    class NetException(msg: String, cause: Throwable?) : Exception(msg, cause)

    private fun netLabel(): String {
        val c = context ?: return "ağ"
        return try {
            val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val n = cm.activeNetwork ?: return "ağ yok"
            val caps = cm.getNetworkCapabilities(n)
            when {
                caps == null -> "ağ"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "VPN"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "mobil veri"
                else -> "ağ"
            }
        } catch (_: Exception) { "ağ" }
    }

    /**
     * Bağlantıyı doğrudan o anki aktif ağa bağlar. Wi-Fi <-> mobil veri geçişinde süreç genelindeki
     * eski (artık ölü) bağlantı havuzunu kullanmaz; DNS de aktif ağın kendi DNS'inden çözülür.
     */
    private fun open(url: URL): HttpURLConnection {
        val c = context
        if (c != null) {
            try {
                val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                val net = cm.activeNetwork
                if (net != null) return net.openConnection(url) as HttpURLConnection
            } catch (_: Exception) { /* düz bağlantıya düş */ }
        }
        return url.openConnection() as HttpURLConnection
    }

    private fun request(method: String, path: String, body: String?, auth: String, apiRegion: String = region): JSONObject {
        var last: java.io.IOException? = null
        // Mobil veride ilk bağlantı (DNS/IPv6/operatör) takılabilir: ağ hatasında bir kez daha dene.
        for (attempt in 0 until 2) {
            try {
                return requestOnce(method, path, body, auth, apiRegion)
            } catch (e: java.io.IOException) {
                last = e
                if (attempt == 0) try { Thread.sleep(500) } catch (_: InterruptedException) {}
            }
        }
        val e = last!!
        val why = when (e) {
            is java.net.UnknownHostException -> "sunucu adı çözülemedi (DNS)"
            is java.net.SocketTimeoutException -> "zaman aşımı"
            is javax.net.ssl.SSLException -> "güvenli bağlantı kurulamadı (${e.message})"
            else -> e.message ?: e.javaClass.simpleName
        }
        throw NetException("İnternet bağlantı hatası (${netLabel()}): $why", e)
    }

    private fun requestOnce(method: String, path: String, body: String?, auth: String, apiRegion: String): JSONObject {
        val conn = open(URL("https://$apiRegion-apia.coolkit.cc$path"))
        try {
            conn.requestMethod = method
            conn.connectTimeout = timeoutMs
            conn.readTimeout = timeoutMs
            conn.useCaches = false
            conn.setRequestProperty("Connection", "close")   // bayat/ölü bağlantı yeniden kullanılmasın
            conn.setRequestProperty("X-CK-Appid", appId)
            conn.setRequestProperty("X-CK-Nonce", UUID.randomUUID().toString().replace("-", "").take(8))
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("Authorization", auth)
            if (body != null) {
                conn.doOutput = true
                conn.outputStream.use { it.write(body.toByteArray()) }
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else (conn.errorStream ?: conn.inputStream)
            val text = stream.bufferedReader().use { it.readText() }
            return try { JSONObject(text) } catch (_: org.json.JSONException) {
                // Operatör/captive portal HTML döndürmüş olabilir
                throw java.io.IOException("sunucudan beklenmeyen yanıt (HTTP $code)")
            }
        } finally {
            conn.disconnect()
        }
    }

    private fun check(r: JSONObject): JSONObject {
        val err = r.optInt("error", -1)
        if (err == 0) return r
        val msg = "eWeLink hata $err: ${r.optString("msg")}"
        if (err == 401 || err == 402 || err == 406) throw AuthException(msg)
        throw Exception(msg)
    }

    /** eWeLink'ten dönen "code"u gerçek access/refresh token ile değiştirir. */
    fun exchangeCode(code: String, redirectUrl: String, codeRegion: String?) {
        if (!configured) throw Exception("App ID/Secret derlemeye eklenmemiş (GitHub Secrets).")
        val body = JSONObject()
            .put("code", code)
            .put("redirectUrl", redirectUrl)
            .put("grantType", "authorization_code")
            .toString()
        val r = request("POST", "/v2/user/oauth/token", body, "Sign " + sign(body), codeRegion ?: region)
        check(r)
        val data = r.getJSONObject("data")
        accessToken = data.getString("accessToken")
        refreshToken = data.getString("refreshToken")
        if (codeRegion != null) region = codeRegion
    }

    /** accessToken süresi dolunca refreshToken ile yenisini alır (aynı anda tek yenileme). */
    fun doRefresh() = synchronized(REFRESH_LOCK) { doRefreshLocked() }

    private fun doRefreshLocked() {
        val rt = refreshToken ?: throw AuthException("Oturum yok, yeniden giriş yap.")
        val body = JSONObject().put("rt", rt).toString()
        // Resmi dokümanda yenileme, mevcut access token ile (Bearer) yapılır; olmazsa imzalı dene
        val attempts = mutableListOf<String>()
        accessToken?.let { attempts.add("Bearer $it") }
        attempts.add("Sign " + sign(body))
        var last: Exception? = null
        for (auth in attempts) {
            try {
                val r = check(request("POST", "/v2/user/refresh", body, auth))
                val data = r.getJSONObject("data")
                accessToken = data.getString("at")
                refreshToken = data.optString("rt", rt)
                return
            } catch (e: Exception) { last = e }
        }
        throw last ?: Exception("Yenileme başarısız")
    }

    /** Çok kanallı cihaz (switches dizisi) mı? getSwitch/setSwitch bunu günceller. */
    var multiChannel: Boolean = false

    private fun statusParams(deviceId: String): JSONObject {
        val r = check(request("GET", "/v2/device/thing/status?type=1&id=$deviceId", null, "Bearer $accessToken"))
        val p = r.getJSONObject("data").getJSONObject("params")
        multiChannel = p.optJSONArray("switches") != null
        return p
    }

    /** Cihazın kayıtlı zamanlayıcı listesini durum uç noktasından okur. */
    fun getTimerList(deviceId: String): JSONArray {
        return statusParams(deviceId).optJSONArray("timers") ?: JSONArray()
    }

    fun getSwitch(deviceId: String, outlet: Int): Boolean {
        val p = statusParams(deviceId)
        val arr = p.optJSONArray("switches")
        if (arr != null) {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                if (o.optInt("outlet", i) == outlet) return o.optString("switch") == "on"
            }
            return false
        }
        return p.optString("switch") == "on"
    }

    /** Tek ya da çok kanallı cihaza doğru biçimde aç/kapat komutu gönderir. */
    fun setSwitch(deviceId: String, outlet: Int, on: Boolean) {
        statusParams(deviceId) // multiChannel'ı belirle
        val v = if (on) "on" else "off"
        val params = if (multiChannel)
            JSONObject().put("switches", JSONArray().put(JSONObject().put("switch", v).put("outlet", outlet)))
        else JSONObject().put("switch", v)
        setParams(deviceId, params)
    }

    /** Hesaptaki cihazları listeler (ad, id, çevrimiçi). */
    fun listDevices(): JSONArray {
        val r = check(request("GET", "/v2/device/thing", null, "Bearer $accessToken"))
        val list = r.getJSONObject("data").optJSONArray("thingList") ?: JSONArray()
        val out = JSONArray()
        for (i in 0 until list.length()) {
            val d = list.getJSONObject(i).optJSONObject("itemData") ?: continue
            out.put(JSONObject()
                .put("id", d.optString("deviceid"))
                .put("name", d.optString("name"))
                .put("online", d.optBoolean("online", false)))
        }
        return out
    }

    /** Teşhis: cihazın bildirdiği tüm parametre adlarını ve çevrimiçi durumunu döndürür. */
    fun describeDevice(deviceId: String): String {
        val r = check(request("GET", "/v2/device/thing/status?type=1&id=$deviceId", null, "Bearer $accessToken"))
        val p = r.getJSONObject("data").getJSONObject("params")
        val keys = p.keys().asSequence().toList().joinToString(",")
        return "parametreler: $keys; switch=${p.optString("switch")}; switches=${p.opt("switches")}; online=${p.opt("online")}; timers=${p.opt("timers").toString().take(500)}"
    }

    /** Teşhis: cihazın şu anki zamanlayıcı listesini ham haliyle döndürür. */
    fun rawTimers(deviceId: String): String {
        val p = statusParams(deviceId)
        return "kanal=${if (multiChannel) "çok" else "tek"}; timers=${p.opt("timers")}; pulses=${p.opt("pulses")}; configure=${p.opt("configure")}; swMode=${p.opt("swMode")}"
    }

    /** Cihazın kendi "inching" özelliği: açılınca widthMs sonra kendiliğinden kapanır (500 ms katları, en çok 10 saat). */
    fun setPulse(deviceId: String, outlet: Int, enable: Boolean, widthMs: Long) {
        val w = ((widthMs.coerceIn(500L, 36_000_000L) / 500L) * 500L).toInt()
        val o = JSONObject().put("outlet", outlet).put("pulse", if (enable) "on" else "off")
            .put("switch", "on").put("width", w)
        setParams(deviceId, JSONObject().put("pulses", JSONArray().put(o)))
    }

    fun setParams(deviceId: String, params: JSONObject) {
        val body = JSONObject().put("type", 1).put("id", deviceId).put("params", params).toString()
        check(request("POST", "/v2/device/thing/status", body, "Bearer $accessToken"))
    }
}
