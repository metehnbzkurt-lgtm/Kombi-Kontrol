package com.kombikontrol.app

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Kombi devreye girince / çıkınca (komut cihazdan DOĞRULANDIKTAN sonra) normal bir telefon bildirimi gönderir.
 * Bildirim sesi/titreşimi telefonun varsayılan bildirim sesidir; Ayarlar > Bildirimler'den değiştirilebilir.
 */
object Notifier {
    private const val CHANNEL = "kombi_olaylar"
    private const val ID_STATE = 4201
    private const val ID_ERROR = 4202

    fun announce(context: Context, isOn: Boolean) {
        post(context, ID_STATE, if (isOn) "Kombi çalışmaya başladı" else "Kombi durduruldu", true)
    }

    fun failure(context: Context, text: String) {
        post(context, ID_ERROR, text, false)
    }

    private fun ensureChannel(nm: NotificationManager) {
        if (nm.getNotificationChannel(CHANNEL) != null) return
        val ch = NotificationChannel(CHANNEL, "Kombi durumu", NotificationManager.IMPORTANCE_DEFAULT)
        ch.description = "Kombi çalışmaya başladığında veya durduğunda bildirim"
        ch.setSound(
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION),
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        ch.enableVibration(true)
        ch.setShowBadge(false)
        nm.createNotificationChannel(ch)
    }

    private fun post(context: Context, id: Int, title: String, normal: Boolean) {
        val app = context.applicationContext
        try {
            if (Build.VERSION.SDK_INT >= 33 &&
                app.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                ActionLog.add(app, "bildirim", null, false, "Bildirim izni kapalı (Ayarlar > Arka plan durumu)")
                return
            }
            val nm = app.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            ensureChannel(nm)
            val open = PendingIntent.getActivity(
                app, 0,
                Intent(app, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val time = SimpleDateFormat("HH:mm", Locale("tr", "TR")).format(Date())
            val n = Notification.Builder(app, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat_kombi)
                .setColor(0xFFF7A833.toInt())
                .setContentTitle(title)
                .setContentText(if (normal) "Saat $time" else "Saat $time · uygulamayı açıp kontrol et")
                .setCategory(Notification.CATEGORY_STATUS)
                .setAutoCancel(true)
                .setContentIntent(open)
                .build()
            nm.notify(id, n)
        } catch (e: Exception) {
            ActionLog.add(app, "bildirim", null, false, "Bildirim gönderilemedi: ${e.message}")
        }
    }
}
