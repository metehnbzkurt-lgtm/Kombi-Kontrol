package com.kombikontrol.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import java.util.concurrent.Executors

/** HTML arayüzü (window.KombiNative) ile eWeLink arasındaki köprü. Şifre hiç saklanmaz. */
class KombiBridge(private val activity: Activity, private val web: WebView) {

    // Token'lar ayrı, şifrelenmiş bir dosyada tutulur (EncryptedSharedPreferences).
    private val securePrefs = SecureStore.get(activity)
    // Şifre/email İÇERMEYEN ayarlar (bölge, cihaz ID, zamanlamalar) normal prefs'te kalabilir.
    private val prefs = activity.getSharedPreferences("kombi", Context.MODE_PRIVATE)
    private val io = Executors.newSingleThreadExecutor()
    private val client = EweLinkClient(BuildConfig.EWELINK_APP_ID, BuildConfig.EWELINK_APP_SECRET)

    private var schedulesJson: String = prefs.getString("schedules", "[]") ?: "[]"
    private var offAtMs: Long = prefs.getLong("offAt", 0L)

    companion object {
        const val REDIRECT_URL = "https://metehnbzkurt-lgtm.github.io/Kombi-Kontrol/callback.html"
    }

    init {
        client.region = prefs.getString("region", "eu") ?: "eu"
        client.accessToken = securePrefs.getString("accessToken", null)
        client.refreshToken = securePrefs.getString("refreshToken", null)
    }

    // ---------- JS'e geri bildirim ----------
    private fun js(code: String) = activity.runOnUiThread { web.evaluateJavascript(code, null) }
    private fun result(ok: Boolean, msg: String) =
        js("window.onNativeResult && window.onNativeResult($ok, ${JSONObject.quote(msg)})")

    // ---------- Yardımcılar ----------
    private fun deviceId(): String {
        val d = prefs.getString("deviceId", "") ?: ""
        if (d.isEmpty()) throw Exception("Cihaz ID girilmemiş (Ayarlar).")
        return d
    }

    private fun persistTokens() {
        securePrefs.edit()
            .putString("accessToken", client.accessToken)
            .putString("refreshToken", client.refreshToken)
            .apply()
        prefs.edit().putString("region", client.region).apply()
    }

    private fun ensureLoggedIn() {
        if (client.accessToken != null) return
        if (client.refreshToken != null) {
            client.doRefresh()
            persistTokens()
            return
        }
        throw EweLinkClient.AuthException("Giriş yapılmamış. Ayarlar > eWeLink ile Oturum Aç.")
    }

    private fun <T> withLogin(block: () -> T): T {
        ensureLoggedIn()
        return try {
            block()
        } catch (e: EweLinkClient.AuthException) {
            val first = e.message ?: ""
            // Token başka bölgede geçerli olabilir: diğer bölgeleri dene
            val original = client.region
            for (r in listOf("as", "eu", "us", "cn")) {
                if (r == original) continue
                client.region = r
                try {
                    val res = block()
                    persistTokens() // doğru bölgeyi kaydet
                    return res
                } catch (x: EweLinkClient.AuthException) {
                    // bu bölgede de olmadı
                } catch (x: Exception) {
                    client.region = original
                    break
                }
            }
            client.region = original
            try {
                client.doRefresh()
                persistTokens()
            } catch (e2: Exception) {
                // Yenileme olmadı: kayıtlı oturumu temizle, yeniden giriş istesin
                client.accessToken = null
                client.refreshToken = null
                securePrefs.edit().remove("accessToken").remove("refreshToken").apply()
                throw EweLinkClient.AuthException("Oturum yenilenemedi, ayarlardan yeniden giriş yap. [$first | ${e2.message}]")
            }
            block()
        }
    }

    private fun uuidOf(key: String) = UUID.nameUUIDFromBytes(("kombi-$key").toByteArray()).toString()

    /** Yerel saat -> UTC cron (eWeLink tekrarlayan zamanlayıcılar UTC çalışır). Haftanın günü 0=Pazar. */
    private fun repeatTimer(s: JSONObject): JSONObject {
        val parts = s.getString("time").split(":")
        val offsetMin = TimeZone.getDefault().getOffset(System.currentTimeMillis()) / 60000
        var total = parts[0].toInt() * 60 + parts[1].toInt() - offsetMin
        var dayShift = 0
        while (total < 0) { total += 1440; dayShift-- }
        while (total >= 1440) { total -= 1440; dayShift++ }
        val days = when (s.optString("days", "all")) {
            "weekday" -> listOf(1, 2, 3, 4, 5)
            "weekend" -> listOf(0, 6)
            else -> (0..6).toList()
        }
        val utcDays = days.map { ((it + dayShift) % 7 + 7) % 7 }.sorted().joinToString(",")
        val cron = "${total % 60} ${total / 60} * * $utcDays"
        return JSONObject()
            .put("enabled", 1)
            .put("mId", uuidOf("s-" + s.opt("id").toString()))
            .put("type", "repeat")
            .put("at", cron)
            .put("coolkit_timer_type", "repeat")
            .put("do", doBlock(s.optString("action") == "ON"))
    }

    private fun outlet(): Int = prefs.getInt("outlet", 0)

    /** Zamanlayıcı "do" bloğu: çok kanallı cihazda kanal numarası da gerekir. */
    private fun doBlock(on: Boolean): JSONObject {
        val o = JSONObject().put("switch", if (on) "on" else "off")
        if (client.multiChannel) o.put("outlet", outlet())
        return o
    }

    /** Geri sayım / güvenlik kapatması: belirli bir anda kombiyi kapat. */
    private fun onceTimer(ms: Long): JSONObject {
        val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US)
        fmt.timeZone = TimeZone.getTimeZone("UTC")
        return JSONObject()
            .put("enabled", 1)
            .put("mId", uuidOf("countdown"))
            .put("type", "once")
            .put("at", fmt.format(Date(ms)))
            .put("coolkit_timer_type", "delay")
            .put("do", doBlock(false))
    }

    /** 4002 = kontrol başarısız; cihazın gerçek durumunu da ekleyerek açıklar. */
    private fun explain(e: Exception): String {
        val m = e.message ?: "Bilinmeyen hata"
        if (!m.contains("4002")) return m
        val info = try { withLogin { client.describeDevice(deviceId()) } } catch (x: Exception) { "alınamadı" }
        return "$m (cihaz çevrimdışı olabilir ya da zamanlayıcıyı desteklemiyor) [$info]"
    }

    private fun pushTimers() {
        val devId = deviceId()
        withLogin { client.getSwitch(devId, outlet()) } // multiChannel bilgisini günceller
        val arr = JSONArray()
        val src = JSONArray(schedulesJson)
        for (i in 0 until src.length()) {
            val s = src.getJSONObject(i)
            if (s.optBoolean("active", true)) arr.put(repeatTimer(s))
        }
        if (offAtMs > System.currentTimeMillis()) arr.put(onceTimer(offAtMs))
        val id = deviceId()
        withLogin { client.setParams(id, JSONObject().put("timers", arr)) }
    }

    // ---------- OAuth girişi ----------
    /** HTML'den çağrılır: eWeLink'in kendi giriş sayfasını sistem tarayıcısında açar. */
    @JavascriptInterface
    fun startOAuthLogin() {
        if (!client.configured) {
            result(false, "App ID/Secret derlemeye eklenmemiş (GitHub Secrets).")
            return
        }
        activity.runOnUiThread {
            try {
                val state = UUID.randomUUID().toString()
                val url = client.buildAuthorizeUrl(REDIRECT_URL, state)
                val i = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                activity.startActivity(i)
            } catch (e: android.content.ActivityNotFoundException) {
                result(false, "Telefonda web tarayıcı bulunamadı.")
            } catch (e: Exception) {
                result(false, "Giriş başlatılamadı: ${e.message}")
            }
        }
    }

    /** MainActivity, kombikontrol://oauth/callback yönlendirmesini yakalayınca burayı çağırır. */
    fun handleOAuthRedirect(uri: Uri) {
        val code = uri.getQueryParameter("code")
        val region = uri.getQueryParameter("region")
        if (code == null) {
            result(false, "Giriş iptal edildi veya kod alınamadı.")
            return
        }
        io.execute {
            try {
                client.exchangeCode(code, REDIRECT_URL, region)
                persistTokens()
                js("window.onOAuthResult && window.onOAuthResult(true, 'Giriş başarılı')")
            } catch (e: Exception) {
                js("window.onOAuthResult && window.onOAuthResult(false, ${JSONObject.quote(e.message ?: "Giriş hatası")})")
            }
        }
    }

    @JavascriptInterface
    fun saveOutlet(n: Int) {
        prefs.edit().putInt("outlet", n.coerceIn(0, 3)).apply()
    }

    @JavascriptInterface
    fun listDevices() {
        io.execute {
            try {
                val arr = withLogin { client.listDevices() }
                js("window.onDevices && window.onDevices(${JSONObject.quote(arr.toString())})")
            } catch (e: Exception) {
                result(false, "Cihazlar alınamadı: ${e.message}")
            }
        }
    }

    @JavascriptInterface
    fun logout() {
        client.accessToken = null
        client.refreshToken = null
        securePrefs.edit().remove("accessToken").remove("refreshToken").apply()
        result(true, "Çıkış yapıldı")
    }

    // ---------- JS'ten çağrılanlar ----------
    @JavascriptInterface
    fun getConfig(): String = JSONObject()
        .put("region", prefs.getString("region", "eu"))
        .put("deviceId", prefs.getString("deviceId", ""))
        .put("outlet", outlet())
        .put("keysOk", client.configured)
        .put("loggedIn", client.accessToken != null || client.refreshToken != null)
        .toString()

    /** Artık sadece bölge ve cihaz ID; email/şifre YOK. */
    @JavascriptInterface
    fun saveConfig(region: String, deviceId: String) {
        val loggedIn = client.accessToken != null || client.refreshToken != null
        val editor = prefs.edit().putString("deviceId", deviceId)
        if (!loggedIn) { editor.putString("region", region); client.region = region }
        editor.apply() // girişliyken bölge, eWeLink'in bildirdiği bölgede kalır
    }

    @JavascriptInterface
    fun getStatus() {
        io.execute {
            try {
                val id = deviceId()
                val on = withLogin { client.getSwitch(id, outlet()) }
                js("window.onNativeStatus && window.onNativeStatus($on)")
            } catch (e: Exception) {
                result(false, "Durum alınamadı: ${explain(e)}")
            }
        }
    }

    /** autoOffMin > 0 ise cihaz içinde o kadar dakika sonra kapanma zamanlayıcısı da yazılır. */
    @JavascriptInterface
    fun setSwitch(on: Boolean, autoOffMin: Int) {
        io.execute {
            try {
                val id = deviceId()
                withLogin { client.setSwitch(id, outlet(), on) }
                offAtMs = if (on && autoOffMin > 0) System.currentTimeMillis() + autoOffMin * 60000L else 0L
                prefs.edit().putLong("offAt", offAtMs).apply()
                try {
                    pushTimers()
                    result(true, "Tamam")
                } catch (te: Exception) {
                    result(false, "Kombi komutu gitti, ama otomatik kapanma zamanlayıcısı yazılamadı: ${explain(te)}")
                }
            } catch (e: Exception) {
                result(false, "Komut gönderilemedi: ${explain(e)}")
            }
        }
    }

    @JavascriptInterface
    fun syncSchedules(json: String) {
        schedulesJson = json
        prefs.edit().putString("schedules", json).apply()
        io.execute {
            try {
                pushTimers()
                result(true, "Zamanlamalar cihaza yazıldı")
            } catch (e: Exception) {
                result(false, "Zamanlamalar yazılamadı: ${explain(e)}")
            }
        }
    }

    @Suppress("DEPRECATION")
    @JavascriptInterface
    fun setTheme(dark: Boolean) {
        activity.runOnUiThread {
            val c = if (dark) 0xFF06090F.toInt() else 0xFFEEF1F7.toInt()
            activity.window.statusBarColor = c
            activity.window.navigationBarColor = c
            web.setBackgroundColor(c)
            var f = activity.window.decorView.systemUiVisibility
            f = if (dark) f and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv() else f or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            if (Build.VERSION.SDK_INT >= 26) {
                f = if (dark) f and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv() else f or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            }
            activity.window.decorView.systemUiVisibility = f
        }
    }
}
