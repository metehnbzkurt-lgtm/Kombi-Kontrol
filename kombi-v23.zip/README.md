# Kombi Kontrol V23 (Android)

HTML arayüz (`app/src/main/assets/index.html`) WebView içinde açılır; Kotlin tarafı eWeLink ile konuşur.
Derleme ve eWeLink kurulumu için V13 README'sindeki adımlar aynen geçerli (GitHub Secrets: `EWELINK_APP_ID`, `EWELINK_APP_SECRET`).

## V23 değişiklikleri
- **Sesli konuşma kaldırıldı**: kombi devreye girince/çıkınca normal telefon bildirimi gelir (varsayılan bildirim sesi; ses ve izin Ayarlar > Bildirim ayarları'ndan değiştirilebilir). Android 13+ ilk açılışta bildirim izni sorar.
- **Android 10+ (minSdk 29)**, hızlı açılış (şifreli depo ve WorkManager arka planda başlar), arka plana geçince WebView durur, animasyonlar hafifletildi (bulanıklık efekti yok, daha az parçacık, ekran kapalıyken animasyon durur), hata ayıklama yükü kapalı.
- **Ayar/istatistik güvenliği**: tüm veriler uygulamanın özel alanında tutulur (dosya yöneticisinden görünmez, silinemez; yalnızca "Verileri temizle"/kaldırma siler). Ayrıca zamanlamalar, tatil modu, tema, gaz fiyatı ve istatistik yedeği Android Yedekleme'ye dahildir; WebView verisi silinirse otomatik geri yüklenir. eWeLink token'ları yedeğe girmez (yeniden giriş gerekir).
- **Üzerine güncelleme**: sabit imza anahtarı (`app/kombi-key.p12`) eklendi; her GitHub derlemesi aynı anahtarla imzalanır, `versionCode` 23. Anahtarı silme/değiştirme, repo'yu özel (private) tut.

> İlk geçişte: V22 ve öncesi her derlemede rastgele imza kullanıldığı için bu sürümü kurmadan önce eski uygulamayı **bir kez** kaldırmak gerekir. Bundan sonraki tüm sürümler üzerine güncellenir.

## V22 değişiklikleri
- **Hava durumuna bağlı animasyonlar**: dalgalanan ışık kaldırıldı; kart artık havaya göre değişir (güneşli: ışınlar, gece: yıldız + kayan yıldız, bulutlu/parçalı: süzülen bulutlar, yağmur, kar, sis, fırtına: yağmur + şimşek). Aydınlık/karanlık temaya uyumlu.
- **Ayarlar > İstatistik ve Gaz Fiyatı**: "İstatistikleri Sıfırla" (iki dokunuşla onay) ve doğalgaz birim fiyatı (₺/kWh) güncelleme.
- **İstatistikler uygulama kapalıyken de kaydedilir**: telefon alarmı/komutu ile biten her çalışma Kotlin tarafında kaydedilir, uygulama açılınca istatistiğe eklenir (çift sayım engellenir). Ayrıca istatistik + fiyat yedeği telefonda tutulur.
- **"Cihaz Bilgisini Göster" kaldırıldı** (hata veriyordu).
- **eWeLink girişinden sonra cihazlar otomatik listelenir**, kayıtlı ID hesapta yoksa çevrimiçi ilk cihazın ID'si otomatik yazılır/kaydedilir.

## V21 değişiklikleri (zamanlama güvenilirliği)
- **Tam zamanlı alarm izni**: `SCHEDULE_EXACT_ALARM` (Android 12/12L) + `USE_EXACT_ALARM` (Android 13+). İzin yoksa Ayarlar > Arka Plan Durumu'nda uyarı çıkar.
- **Alarm zinciri kopmaz**: her alarm, komuttan ÖNCE bir sonrakini kurar.
- **Doğrulanmış komut**: röleye komut gönderildikten sonra durum cihazdan geri okunur; sadece doğrulanırsa başarılı sayılır ve sesli duyuru yapılır.
- **WorkManager**: alarm anında hızlı deneme (4 sn) yapılır; başarısızsa ya da süreç öldürülürse kalıcı iş ağ gelince 30 sn aralıklarla yeniden dener (kapatma 3 saat, açma 90 dk boyunca).
- **Bekçi (15 dk)**: silinmiş alarmları yeniden kurar, kaçırılan zamanlamayı (30 dk içinde) telafi eder, gecikmiş kapanmayı yeniden gönderir.
- **Reboot / güncelleme / saat değişimi / izin değişimi** sonrası alarmlar yeniden kurulur.
- **4 saat güvenlik kapatması** artık zamanlamayla açılan kombi için de telefonda kurulur; zamanlama OFF'u eski kapanma alarmını iptal eder.
- **Tek doğru kaynak**: cihaz içi (bulut) zamanlayıcılar kullanılmaz; önceki sürümlerin yazdığı zamanlayıcılar cihazdan bir kez silinir (telefon komutlarıyla çakışıp röleyi geri kapatmasın).
- **Token yarışı** giderildi (taze token okuma, süreç geneli yenileme kilidi, oturum silmeden önce yeniden deneme).
- **TTS**: `<queries>` eklendi (Android 11+), zaman aşımı korumalı.
- **Son işlemler**: Ayarlar > Arka Plan Durumu'nda her alarm/komut/yeniden deneme kaydı görünür.

## Kurulumdan sonra (önemli)
1. Uygulamayı bir kez aç (alarmlar kurulur). Ayarlar > Arka Plan Durumu'nda iki işaret de ✅ olmalı.
2. "Tam zamanlı alarm iznini aç" ve "Pil optimizasyonunu kapat" butonlarına bas.
3. Xiaomi/Huawei/Oppo/Samsung'ta: Uygulama ayarları > Otomatik başlatma AÇIK, pil: "Kısıtlama yok".
4. Uygulamayı son uygulamalardan kaydırarak kapatmak sorun değil; "Zorla durdur" yaparsan Android tüm alarmları siler, uygulamayı bir kez açman gerekir.
5. Telefon sessiz/Rahatsız Etmeyin modundaysa sesli duyuru duyulmaz (komut yine de çalışır).
