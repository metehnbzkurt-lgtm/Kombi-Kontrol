package com.kombikontrol.app

import android.content.Context
import android.media.AudioAttributes
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Türkçe sesli duyuru. Sadece komut cihazdan DOĞRULANDIKTAN sonra çağrılır.
 * TTS yanıt vermezse 7 sn sonra kendiliğinden bırakır (alıcıyı kilitlemez).
 */
object VoiceAnnouncer {

    fun announce(context: Context, isOn: Boolean, onFinished: () -> Unit = {}) {
        speak(context, if (isOn) "Kombi çalışmaya başladı." else "Kombi durduruldu.", onFinished)
    }

    /** Arka plan iş parçacığında sesin bitmesini (en çok 8 sn) bekler. */
    fun announceBlocking(context: Context, isOn: Boolean) {
        val latch = CountDownLatch(1)
        announce(context, isOn) { latch.countDown() }
        latch.await(8, TimeUnit.SECONDS)
    }

    fun speak(context: Context, phrase: String, onFinished: () -> Unit = {}) {
        val app = context.applicationContext
        val finished = AtomicBoolean(false)
        var ttsRef: TextToSpeech? = null

        fun done() {
            if (finished.compareAndSet(false, true)) {
                try { ttsRef?.shutdown() } catch (_: Exception) {}
                onFinished()
            }
        }

        try {
            Handler(Looper.getMainLooper()).postDelayed({ done() }, 7000L)
            ttsRef = TextToSpeech(app) { status ->
                val tts = ttsRef
                val lang = if (tts != null && status == TextToSpeech.SUCCESS) tts.setLanguage(Locale("tr", "TR")) else TextToSpeech.LANG_NOT_SUPPORTED
                if (tts == null || lang == TextToSpeech.LANG_MISSING_DATA || lang == TextToSpeech.LANG_NOT_SUPPORTED) {
                    ActionLog.add(app, "ses", null, false, "Türkçe TTS başlatılamadı (ses paketi/motor yok)")
                    done()
                } else {
                    tts.setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    tts.setSpeechRate(0.92f)
                    tts.setPitch(1.0f)
                    tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {}
                        override fun onDone(utteranceId: String?) { done() }
                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) { done() }
                        override fun onError(utteranceId: String?, errorCode: Int) { done() }
                    })
                    tts.speak(phrase, TextToSpeech.QUEUE_FLUSH, null, UUID.randomUUID().toString())
                }
            }
        } catch (_: Exception) {
            done()
        }
    }
}
