package com.kombikontrol.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.os.Build

/** Tam zamanlı alarm yardımcıları: izin kontrolü + güvenli kurma. */
object AlarmUtil {

    fun canExact(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        return try { am.canScheduleExactAlarms() } catch (_: Exception) { false }
    }

    /** true = tam zamanlı kuruldu, false = izin yok, yaklaşık (gecikebilir) alarm kuruldu. */
    fun set(context: Context, atMs: Long, pi: PendingIntent): Boolean {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (canExact(context)) {
            try {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMs, pi)
                return true
            } catch (_: SecurityException) {
                // izin sırasında geri alınmış olabilir; aşağıdaki yedeğe düş
            }
        }
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMs, pi)
        return false
    }
}
