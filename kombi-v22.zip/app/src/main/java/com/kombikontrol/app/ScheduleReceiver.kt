package com.kombikontrol.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Günlük/haftalık zamanlama alarmı tetiklenince:
 *  1) ÖNCE bir sonraki alarmı kurar (zincir hiçbir koşulda kopmaz),
 *  2) sonra komutu gönderir ve doğrular (CommandDispatcher).
 */
class ScheduleReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        val scheduleId = intent.getLongExtra("scheduleId", -1L)
        val on = intent.getBooleanExtra("on", true)
        val target = intent.getLongExtra("target", System.currentTimeMillis())
        if (scheduleId < 0) return

        val active = ScheduleAlarmManager.rescheduleAfterFire(app, scheduleId)
        if (!active) return // silinmiş/pasif zamanlamanın eski alarmı

        ScheduleAlarmManager.markRun(app, scheduleId, target)
        val lateSec = (System.currentTimeMillis() - target) / 1000
        ActionLog.add(app, "zamanlama", on, true, "Alarm alındı (gecikme ${lateSec} sn)")

        CommandDispatcher.fromReceiver(app, on, "zamanlama", goAsync())
    }
}
