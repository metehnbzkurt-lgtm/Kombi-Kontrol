package com.kombikontrol.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Arka plan işlemlerinin son 40 kaydı (uygulamada "Son işlemler" olarak gösterilir). */
object ActionLog {
    private const val KEY = "actionLog"
    private const val MAX = 40

    private fun prefs(c: Context) = c.getSharedPreferences("kombi", Context.MODE_PRIVATE)

    /** on: true=AÇ, false=KAPAT, null=bilgi satırı. */
    @Synchronized
    fun add(context: Context, origin: String, on: Boolean?, ok: Boolean, msg: String) {
        try {
            val p = prefs(context.applicationContext)
            val arr = JSONArray(p.getString(KEY, "[]") ?: "[]")
            arr.put(
                JSONObject()
                    .put("t", System.currentTimeMillis())
                    .put("o", origin)
                    .put("a", when (on) { true -> "AÇ"; false -> "KAPAT"; null -> "-" })
                    .put("ok", ok)
                    .put("m", msg)
            )
            val out = JSONArray()
            for (i in maxOf(0, arr.length() - MAX) until arr.length()) out.put(arr.get(i))
            p.edit().putString(KEY, out.toString()).apply()
        } catch (_: Exception) {
        }
    }

    @Synchronized
    fun all(context: Context): JSONArray = try {
        JSONArray(prefs(context.applicationContext).getString(KEY, "[]") ?: "[]")
    } catch (_: Exception) {
        JSONArray()
    }

    @Synchronized
    fun clear(context: Context) {
        prefs(context.applicationContext).edit().remove(KEY).apply()
    }
}
