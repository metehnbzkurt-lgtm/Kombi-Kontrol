package com.kombikontrol.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent

/**
 * Kombiyi belirtilen zamanda kapatacak sistem alarmını kurar/iptal eder.
 * Tam zamanlı alarm izni varsa tam zamanında, yoksa yaklaşık zamanda tetiklenir.
 */
object AutoOffScheduler {
    private const val REQUEST_CODE = 1001

    private fun pendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, AutoOffReceiver::class.java)
        return PendingIntent.getBroadcast(
            context, REQUEST_CODE, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun schedule(context: Context, targetAtMs: Long) {
        val app = context.applicationContext
        try {
            val exact = AlarmUtil.set(app, targetAtMs, pendingIntent(app))
            if (!exact) ActionLog.add(app, "alarm", null, false, "Tam zamanlı alarm izni yok: kapanma geç kalabilir")
        } catch (e: Exception) {
            ActionLog.add(app, "alarm", null, false, "Kapanma alarmı kurulamadı: ${e.message}")
        }
    }

    fun cancel(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pendingIntent(context.applicationContext))
    }
}
