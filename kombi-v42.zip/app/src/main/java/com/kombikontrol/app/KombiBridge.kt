package com.kombikontrol.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import java.util.concurrent.Executors

/** HTML arayüzü (window.KombiNative) ile eWeLink arasındaki köprü. Şifre hiç saklanmaz. */
class KombiBridge(private val activity: Activity, private val web: WebView) {

    // Token'lar ayrı, şifrelenmiş bir dosyada tutulur (EncryptedSharedPreferences).
    private val securePrefs by lazy { SecureStore.get(activity) }
    // Şifre/email İÇERMEYEN ayarlar (bölge, cihaz ID, zamanlamalar) normal prefs'te kalabilir.
    private val prefs = activity.getSharedPreferences("kombi", Context.MODE_PRIVATE)
    // Yedeklenen (Android Auto Backup) tek dosya: ayarlar + istatistik. Uygulama içi özel alandadır, dosya yöneticisinden görünmez/silinemez.
    private val keep = activity.getSharedPreferences("kombi_keep", Context.MODE_PRIVATE)
    private val io = Executors.newSingleThreadExecutor()
    private val client = EweLinkClient(BuildConfig.EWELINK_APP_ID, BuildConfig.EWELINK_APP_SECRET)

    private var schedulesJson: String = prefs.getString("schedules", "[]") ?: "[]"

    companion object {
        const val REDIRECT_URL = "https://metehnbzkurt-lgtm.github.io/Kombi-Kontrol/callback.html"
    }

    init {
        client.context = activity.applicationContext
        client.region = prefs.getString("region", "eu") ?: "eu"
    }

    // ---------- JS'e geri bildirim ----------
    private fun js(code: String) = activity.runOnUiThread { web.evaluateJavascript(code, null) }
    private fun result(ok: Boolean, msg: String) =
        js("window.onNativeResult && window.onNativeResult($ok, ${JSONObject.quote(msg)})")

    // ---------- Yardımcılar ----------
    private fun deviceId(): String {
        val d = prefs.getString("deviceId", "") ?: ""
        if (d.isEmpty()) throw Exception("Cihaz ID girilmemiş (Ayarlar).")
        return d
    }

    private fun persistTokens() {
        securePrefs.edit()
            .putString("accessToken", client.accessToken)
            .putString("refreshToken", client.refreshToken)
            .apply()
        prefs.edit().putString("region", client.region).apply()
    }

    /** Arka plan alarmı token'ı yenilemiş olabilir: her işlemden önce depodan taze oku. */
    private fun reloadTokens() {
        client.accessToken = securePrefs.getString("accessToken", null)
        client.refreshToken = securePrefs.getString("refreshToken", null)
        client.region = prefs.getString("region", "eu") ?: "eu"
    }

    private fun ensureLoggedIn() {
        if (client.accessToken != null) return
        if (client.refreshToken != null) {
            client.doRefresh()
            persistTokens()
            return
        }
        throw EweLinkClient.AuthException("Giriş yapılmamış. Ayarlar > eWeLink ile Oturum Aç.")
    }

    private fun <T> withLogin(block: () -> T): T {
        reloadTokens()
        ensureLoggedIn()
        return try {
            block()
        } catch (e: EweLinkClient.AuthException) {
            val first = e.message ?: ""
            // Token başka bölgede geçerli olabilir: diğer bölgeleri dene
            val original = client.region
            for (r in listOf("as", "eu", "us", "cn")) {
                if (r == original) continue
                client.region = r
                try {
                    val res = block()
                    persistTokens() // doğru bölgeyi kaydet
                    return res
                } catch (x: EweLinkClient.AuthException) {
                    // bu bölgede de olmadı
                } catch (x: Exception) {
                    client.region = original
                    break
                }
            }
            client.region = original
            try {
                client.doRefresh()
                persistTokens()
            } catch (e2: Exception) {
                // Arka plan bu arada token'ı yenilemiş olabilir: depodaki yeni token ile bir kez daha dene.
                val usedRt = client.refreshToken
                reloadTokens()
                if (client.refreshToken != null && client.refreshToken != usedRt && client.accessToken != null) {
                    return block()
                }
                // Yenileme olmadı: kayıtlı oturumu temizle, yeniden giriş istesin
                client.accessToken = null
                client.refreshToken = null
                securePrefs.edit().remove("accessToken").remove("refreshToken").apply()
                throw EweLinkClient.AuthException("Oturum yenilenemedi, ayarlardan yeniden giriş yap. [$first | ${e2.message}]")
            }
            block()
        }
    }

    private fun uuidOf(key: String) = UUID.nameUUIDFromBytes(("kombi-$key").toByteArray()).toString()

    /** 4002 = kontrol başarısız; cihazın gerçek durumunu da ekleyerek açıklar. */
    private fun explain(e: Exception): String {
        val m = e.message ?: "Bilinmeyen hata"
        if (!m.contains("4002")) return m
        val info = try { withLogin { client.describeDevice(deviceId()) } } catch (x: Exception) { "alınamadı" }
        return "$m (cihaz çevrimdışı olabilir) [$info]"
    }

    private fun outlet(): Int = prefs.getInt("outlet", 0)

    /**
     * V21: Artık cihaz içi (bulut) zamanlayıcı KULLANILMIYOR; tek doğru kaynak telefon alarmları.
     * Önceki sürümlerin cihaza yazdığı bu uygulamaya ait zamanlayıcılar telefon komutlarıyla çakışıp
     * rölenin hemen geri kapanmasına yol açabileceği için bir kez cihazdan silinir.
     */
    private fun cleanupCloudTimers() {
        if (prefs.getBoolean("cloudCleaned21", false)) return
        try {
            val id = deviceId()
            val current = withLogin { client.getTimerList(id) }
            val owned = mutableSetOf<String>()
            owned += prefs.getStringSet("managedTimerIds", emptySet()) ?: emptySet()
            owned += uuidOf("countdown")
            val src = JSONArray(schedulesJson)
            for (i in 0 until src.length()) owned += uuidOf("s-" + src.getJSONObject(i).opt("id").toString())

            val keep = JSONArray()
            var removed = 0
            for (i in 0 until current.length()) {
                val t = current.optJSONObject(i) ?: continue
                if (owned.contains(t.optString("mId"))) removed++ else keep.put(t)
            }
            if (removed > 0) withLogin { client.setParams(id, JSONObject().put("timers", keep)) }
            prefs.edit().putBoolean("cloudCleaned21", true).remove("managedTimerIds").apply()
            ActionLog.add(activity, "sistem", null, true, "Cihazdaki eski zamanlayıcılar temizlendi ($removed)")
        } catch (_: Exception) {
            // cihaz/oturum hazır değil: sonraki açılışta yeniden denenir
        }
    }

    /** Cihazın gerçek durumunu telefon tarafındaki kayıtla (onSince/offAt/alarm) eşitler. */
    private fun syncNativeState(on: Boolean) {
        val now = System.currentTimeMillis()
        if (!on) {
            val prev = prefs.getLong("onSince", 0L)
            if (prev > 0L) CommandRunner.recordSession(activity, prev, minOf(now, prev + CommandRunner.SAFETY_MS))
            if (prev > 0L || prefs.getLong("offAt", 0L) > 0L) {
                prefs.edit().putLong("onSince", 0L).putLong("offAt", 0L).putInt("autoOffAttempts", 0).apply()
                AutoOffScheduler.cancel(activity)
            }
        } else if (prefs.getLong("onSince", 0L) == 0L) {
            val offAt = now + CommandRunner.SAFETY_MS
            prefs.edit().putLong("onSince", now).putLong("offAt", offAt).putInt("autoOffAttempts", 0).apply()
            AutoOffScheduler.schedule(activity, offAt)
        }
    }

    // ---------- OAuth girişi ----------
    /** HTML'den çağrılır: eWeLink'in kendi giriş sayfasını sistem tarayıcısında açar. */
    @JavascriptInterface
    fun startOAuthLogin() {
        if (!client.configured) {
            result(false, "App ID/Secret derlemeye eklenmemiş (GitHub Secrets).")
            return
        }
        activity.runOnUiThread {
            try {
                val state = UUID.randomUUID().toString()
                val url = client.buildAuthorizeUrl(REDIRECT_URL, state)
                val i = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                activity.startActivity(i)
            } catch (e: android.content.ActivityNotFoundException) {
                result(false, "Telefonda web tarayıcı bulunamadı.")
            } catch (e: Exception) {
                result(false, "Giriş başlatılamadı: ${e.message}")
            }
        }
    }

    /** MainActivity, kombikontrol://oauth/callback yönlendirmesini yakalayınca burayı çağırır. */
    fun handleOAuthRedirect(uri: Uri) {
        val code = uri.getQueryParameter("code")
        val region = uri.getQueryParameter("region")
        if (code == null) {
            result(false, "Giriş iptal edildi veya kod alınamadı.")
            return
        }
        io.execute {
            try {
                client.exchangeCode(code, REDIRECT_URL, region)
                persistTokens()
                js("window.onOAuthResult && window.onOAuthResult(true, 'Giriş başarılı')")
            } catch (e: Exception) {
                js("window.onOAuthResult && window.onOAuthResult(false, ${JSONObject.quote(e.message ?: "Giriş hatası")})")
            }
        }
    }

    // ---------- İstatistik: arka plan kayıtları + yedek ----------
    /** Uygulama kapalıyken biten çalışma aralıklarını [{s,e}] verir ve temizler. */
    @JavascriptInterface
    fun takeSessions(): String = CommandRunner.takeSessions(activity)

    /** Arayüzün istatistik/fiyat verisinin yedeği (WebView verisi silinirse geri yüklenir). */
    @JavascriptInterface
    fun saveStats(json: String) { keep.edit().putString("statsBackup", json).apply() }

    @JavascriptInterface
    fun getStats(): String {
        val k = keep.getString("statsBackup", "") ?: ""
        return if (k.isNotEmpty()) k else (prefs.getString("statsBackup", "") ?: "")   // V22'den geçiş
    }

    @JavascriptInterface
    fun resetStats() {
        CommandRunner.clearSessions(activity)
        prefs.edit().remove("statsBackup").apply()
        keep.edit().remove("statsBackup").apply()
    }

    @JavascriptInterface
    fun saveOutlet(n: Int) {
        prefs.edit().putInt("outlet", n.coerceIn(0, 3)).apply()
    }

    @JavascriptInterface
    fun listDevices() {
        io.execute {
            try {
                val arr = withLogin { client.listDevices() }
                js("window.onDevices && window.onDevices(${JSONObject.quote(arr.toString())})")
            } catch (e: Exception) {
                result(false, "Cihazlar alınamadı: ${e.message}")
            }
        }
    }

    @JavascriptInterface
    fun logout() {
        client.accessToken = null
        client.refreshToken = null
        securePrefs.edit().remove("accessToken").remove("refreshToken").apply()
        result(true, "Çıkış yapıldı")
    }

    // ---------- JS'ten çağrılanlar ----------
    @JavascriptInterface
    fun getConfig(): String { reloadTokens(); return configJson() }

    private fun configJson(): String = JSONObject()
        .put("region", prefs.getString("region", "eu"))
        .put("deviceId", prefs.getString("deviceId", ""))
        .put("outlet", outlet())
        .put("onSince", prefs.getLong("onSince", 0L))
        .put("offAt", prefs.getLong("offAt", 0L))
        .put("lastManualAt", prefs.getLong("lastManualAt", 0L))
        .put("keysOk", client.configured)
        .put("loggedIn", client.accessToken != null || client.refreshToken != null)
        .toString()

    /** Artık sadece bölge ve cihaz ID; email/şifre YOK. */
    @JavascriptInterface
    fun saveConfig(region: String, deviceId: String) {
        reloadTokens()
        val loggedIn = client.accessToken != null || client.refreshToken != null
        val editor = prefs.edit().putString("deviceId", deviceId)
        if (!loggedIn) { editor.putString("region", region); client.region = region }
        editor.apply() // girişliyken bölge, eWeLink'in bildirdiği bölgede kalır
    }

    @JavascriptInterface
    fun getStatus() {
        io.execute {
            try {
                val id = deviceId()
                val on = withLogin { client.getSwitch(id, outlet()) }
                syncNativeState(on)
                js("window.onNativeStatus && window.onNativeStatus($on)")
            } catch (e: Exception) {
                result(false, "Durum alınamadı: ${explain(e)}")
            }
        }
    }

    /**
     * Elle aç/kapat. Komut cihazdan geri okunarak doğrulanır; yalnızca doğrulanırsa sesli duyuru yapılır.
     * Açılırken kapanma alarmı (süre sonu / 4 saat güvenlik) telefonda kurulur.
     */
    @JavascriptInterface
    fun setSwitch(on: Boolean, autoOffMin: Int) {
        io.execute {
            try {
                val now = System.currentTimeMillis()
                val seq = CommandRunner.nextSeq(activity)   // bekleyen eski yeniden denemeleri geçersiz kılar
                CommandWorker.cancel(activity)
                prefs.edit().putLong("lastManualAt", now).apply()

                val offAt = if (on) {
                    if (autoOffMin > 0) now + autoOffMin.coerceIn(1, 1439) * 60_000L else now + CommandRunner.SAFETY_MS
                } else 0L

                val alreadyOn = prefs.getLong("onSince", 0L) > 0L
                if (on && alreadyOn) {
                    // Kombi zaten açık: sadece kapanma anını güncelle, tekrar komut/duyuru yapma.
                    prefs.edit().putLong("offAt", offAt).putInt("autoOffAttempts", 0).apply()
                    AutoOffScheduler.schedule(activity, offAt)
                    result(true, "Tamam")
                    return@execute
                }

                var o = CommandRunner.run(activity, on, "elle", fast = false, offAtMs = offAt, seq = seq)
                // Geçici ağ/doğrulama hatasında (ayar/oturum sorunu değilse) bir kez daha dene.
                if (!o.ok && !o.message.contains("girilmemiş") && !o.message.contains("oturumu yok") && !o.message.contains("Secret")) {
                    try { Thread.sleep(2000) } catch (_: InterruptedException) {}
                    if (CommandRunner.currentSeq(activity) == seq) {
                        o = CommandRunner.run(activity, on, "elle (2. deneme)", fast = false, offAtMs = offAt, seq = seq)
                    }
                }
                if (o.ok) {
                    Notifier.announce(activity, on)
                    result(true, if (on) "Kombi açıldı (doğrulandı). Kapanma telefon alarmıyla kuruldu." else "Kombi kapatıldı (doğrulandı).")
                } else {
                    result(false, "Komut uygulanamadı: ${o.message}")
                    js("window.onNativeResume && window.onNativeResume()") // arayüzü gerçek duruma çek
                }
            } catch (e: Exception) {
                result(false, "Komut gönderilemedi: ${e.message}")
                js("window.onNativeResume && window.onNativeResume()")
            }
        }
    }

    /** Günlük zamanlamalar: telefon alarmlarına kurulur (tek doğru kaynak). */
    @JavascriptInterface
    fun syncSchedules(json: String) {
        schedulesJson = json
        prefs.edit().putString("schedules", json).apply()
        io.execute {
            ScheduleAlarmManager.scheduleAll(activity, catchUp = false)
            WatchdogWorker.enqueue(activity)
            cleanupCloudTimers()
            DeviceTimers.sync(activity, force = true)

            val exact = AlarmUtil.canExact(activity)
            val battery = batteryOk()
            val msg = when {
                !exact -> "Zamanlamalar kuruldu ama \"Alarmlar ve hatırlatıcılar\" izni KAPALI: zamanlama geç kalabilir. Ayarlar > Arka plan durumu."
                !battery -> "Zamanlamalar tam zamanlı kuruldu. Pil optimizasyonunu kapatman önerilir (Ayarlar > Arka plan durumu)."
                else -> "Zamanlamalar telefon alarmlarıyla tam zamanlı kuruldu."
            }
            result(true, msg)
        }
    }

    // ---------- Arka plan durumu / izinler ----------
    private fun batteryOk(): Boolean = try {
        val pm = activity.getSystemService(Context.POWER_SERVICE) as PowerManager
        pm.isIgnoringBatteryOptimizations(activity.packageName)
    } catch (_: Exception) { false }

    @JavascriptInterface
    fun getBackgroundStatus(): String = JSONObject()
        .put("exactOk", AlarmUtil.canExact(activity))
        .put("batteryOk", batteryOk())
        .put("sdk", Build.VERSION.SDK_INT)
        .put("notifOk", notifOk())
        .put("next", ScheduleAlarmManager.describe(activity))
        .put("offAt", prefs.getLong("offAt", 0L))
        .put("logs", ActionLog.all(activity))
        .toString()

    private fun notifOk(): Boolean = try {
        val nm = activity.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
        nm.areNotificationsEnabled()
    } catch (_: Exception) { true }

    @JavascriptInterface
    fun openNotificationSettings() {
        activity.runOnUiThread {
            try {
                activity.startActivity(
                    Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                        .putExtra(Settings.EXTRA_APP_PACKAGE, activity.packageName)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (e: Exception) { openAppSettings() }
        }
    }

    @JavascriptInterface
    fun requestExactAlarm() {
        activity.runOnUiThread {
            try {
                if (Build.VERSION.SDK_INT >= 31) {
                    activity.startActivity(
                        Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${activity.packageName}"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } else result(true, "Bu Android sürümünde ek izin gerekmiyor.")
            } catch (e: Exception) { openAppSettings() }
        }
    }

    @JavascriptInterface
    fun requestBatteryExemption() {
        activity.runOnUiThread {
            try {
                activity.startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${activity.packageName}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (e: Exception) {
                try {
                    activity.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (_: Exception) { openAppSettings() }
            }
        }
    }

    @JavascriptInterface
    fun openAppSettings() {
        activity.runOnUiThread {
            try {
                activity.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${activity.packageName}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (_: Exception) {}
        }
    }

    @JavascriptInterface
    fun clearLogs() { ActionLog.clear(activity) }

    /** Telefonun gerçek sistem teması (WebView'in prefers-color-scheme'ine güvenme). */
    @JavascriptInterface
    fun isSystemDark(): Boolean =
        (activity.resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES

    @Suppress("DEPRECATION")
    @JavascriptInterface
    fun setTheme(dark: Boolean) {
        activity.runOnUiThread {
            val c = if (dark) 0xFF06090F.toInt() else 0xFFEEF1F7.toInt()
            activity.window.statusBarColor = c
            activity.window.navigationBarColor = c
            web.setBackgroundColor(c)
            var f = activity.window.decorView.systemUiVisibility
            f = if (dark) f and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv() else f or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            if (Build.VERSION.SDK_INT >= 26) {
                f = if (dark) f and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv() else f or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            }
            activity.window.decorView.systemUiVisibility = f
        }
    }
}
