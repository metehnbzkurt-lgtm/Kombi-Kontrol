package com.kombikontrol.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID

/**
 * Yedek katman: zamanlamadaki yaklaşan en çok 8 AÇ/KAPAT olayını rölenin KENDİ saatine (cihaz içi, tek seferlik
 * zamanlayıcı) yazar. Telefon kapalı/uygulama öldürülmüş olsa bile röle bu olayları kendi başına uygular.
 * Telefon canlıyken pencere her yenilenişte (uygulama açılışı, alarm, bekçi) ileri kayar.
 * Yalnızca bu uygulamanın yazdığı zamanlayıcılar (mId kayıtlı) değiştirilir; diğerlerine dokunulmaz.
 */
object DeviceTimers {
    private const val MAX = 8
    private const val WINDOW_MS = 24 * 3600_000L
    private val lock = Any()

    private fun prefs(c: Context) = c.getSharedPreferences("kombi", Context.MODE_PRIVATE)
    private fun mid(at: Long) = UUID.nameUUIDFromBytes("kombi-ct-$at".toByteArray()).toString()
    private fun iso(at: Long): String {
        val f = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US)
        f.timeZone = TimeZone.getTimeZone("UTC")
        return f.format(Date(at))
    }

    private class Ev(val at: Long, val on: Boolean)

    private fun upcoming(app: Context): List<Ev> {
        val src = try { JSONArray(prefs(app).getString("schedules", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        val now = System.currentTimeMillis()
        val out = mutableMapOf<Long, Ev>()
        for (i in 0 until src.length()) {
            val it = src.optJSONObject(i) ?: continue
            if (!it.optBoolean("active", true)) continue
            val p = it.optString("time", "").split(":")
            val h = p.getOrNull(0)?.toIntOrNull() ?: continue
            val m = p.getOrNull(1)?.toIntOrNull() ?: continue
            val at = ScheduleAlarmManager.nextTriggerMillis(h, m, it.optString("days", "all"))
            if (at - now < 60_000L || at - now > WINDOW_MS) continue   // 1 dk'dan yakın olanı telefon zaten yapar
            out[at] = Ev(at, it.optString("action", "ON") == "ON")
        }
        return out.values.sortedBy { it.at }.take(MAX)
    }

    /** Ağ gerektirir; arka plan iş parçacığından çağrılmalı. Hatalar kayda yazılır, asla fırlatmaz. */
    fun sync(context: Context, force: Boolean = false) {
        val app = context.applicationContext
        synchronized(lock) {
            try { doSync(app, force) }
            catch (e: Throwable) { ActionLog.add(app, "röle zamanlayıcı", null, false, "Cihaza yazılamadı: ${e.message}") }
        }
    }

    private fun doSync(app: Context, force: Boolean) {
        val p = prefs(app)
        val deviceId = p.getString("deviceId", "") ?: ""
        if (deviceId.isEmpty()) return
        val secure = SecureStore.get(app)
        val client = EweLinkClient(BuildConfig.EWELINK_APP_ID, BuildConfig.EWELINK_APP_SECRET)
        if (!client.configured) return
        client.context = app
        client.timeoutMs = 10000
        client.region = p.getString("region", "eu") ?: "eu"
        client.accessToken = secure.getString("accessToken", null)
        client.refreshToken = secure.getString("refreshToken", null)
        if (client.accessToken == null && client.refreshToken == null) return

        val events = upcoming(app)
        val sig = events.joinToString(",") { "${it.at}${if (it.on) "1" else "0"}" }
        val owned = p.getStringSet("devTimerIds", emptySet())?.toSet() ?: emptySet()
        if (!force && sig == p.getString("devTimerSig", "") && (owned.isNotEmpty() || events.isEmpty())) return

        fun persist() {
            secure.edit().putString("accessToken", client.accessToken).putString("refreshToken", client.refreshToken).apply()
            p.edit().putString("region", client.region).apply()
        }
        fun <T> auth(block: () -> T): T {
            if (client.accessToken == null) { client.doRefresh(); persist() }
            return try { block() } catch (e: EweLinkClient.AuthException) { client.doRefresh(); persist(); block() }
        }

        val outlet = p.getInt("outlet", 0)
        val current = auth { client.getTimerList(deviceId) }   // aynı çağrı multiChannel'ı da belirler
        val keep = JSONArray()
        for (i in 0 until current.length()) {
            val t = current.optJSONObject(i) ?: continue
            if (!owned.contains(t.optString("mId"))) keep.put(t)
        }
        val ids = mutableSetOf<String>()
        val all = JSONArray()
        for (i in 0 until keep.length()) all.put(keep.get(i))
        for (e in events) {
            val v = if (e.on) "on" else "off"
            val doObj = if (client.multiChannel)
                JSONObject().put("switches", JSONArray().put(JSONObject().put("switch", v).put("outlet", outlet)))
            else JSONObject().put("switch", v)
            val id = mid(e.at); ids.add(id)
            all.put(
                JSONObject().put("enabled", 1).put("mId", id).put("type", "once")
                    .put("at", iso(e.at)).put("coolkit_timer_type", "once").put("do", doObj)
            )
        }
        auth { client.setParams(deviceId, JSONObject().put("timers", all)) }

        // Doğrulama: cihaz yazdığımız zamanlayıcıları gerçekten tutuyor mu?
        val after = try { client.getTimerList(deviceId) } catch (_: Exception) { null }
        var found = -1
        if (after != null) { found = 0; for (i in 0 until after.length()) if (ids.contains(after.optJSONObject(i)?.optString("mId") ?: "")) found++ }
        p.edit().putStringSet("devTimerIds", ids).putString("devTimerSig", sig).apply()
        if (found == ids.size) {
            if (ids.isNotEmpty() || owned.isNotEmpty()) ActionLog.add(app, "röle zamanlayıcı", null, true, "Röleye ${ids.size} yaklaşan olay yazıldı (telefon kapalıyken de çalışır)")
        } else {
            ActionLog.add(app, "röle zamanlayıcı", null, false, "Yazıldı ama cihaz ${if (found < 0) "okunamadı" else "$found/${ids.size} kabul etti"} (zamanlayıcı sınırı olabilir)")
        }
    }
}
