package com.kombikontrol.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import org.json.JSONArray

/**
 * Aktif zamanlama / döngü varken uygulamayı canlı tutan sessiz ön plan servisi.
 * Uygulama son uygulamalardan kaydırılınca Android süreci/alarmları öldürmesin diye (ön plan servisi olan uygulama
 * kaydırınca durdurulmaz). Aktif zamanlama yoksa kendini kapatır.
 */
class KeepAliveService : Service() {
    companion object {
        private const val CHANNEL = "kombi_plan"
        private const val NID = 4204

        fun hasActive(c: Context): Boolean {
            val s = c.getSharedPreferences("kombi", Context.MODE_PRIVATE).getString("schedules", "[]") ?: "[]"
            return try {
                val a = JSONArray(s)
                (0 until a.length()).any { a.optJSONObject(it)?.optBoolean("active", true) == true }
            } catch (_: Exception) { false }
        }

        /** Aktif zamanlama varsa başlatır, yoksa durdurur. Hata fırlatmaz. */
        fun refresh(context: Context) {
            val app = context.applicationContext
            try {
                if (hasActive(app)) app.startForegroundService(Intent(app, KeepAliveService::class.java))
                else app.stopService(Intent(app, KeepAliveService::class.java))
            } catch (e: Throwable) {
                ActionLog.add(app, "sistem", null, false, "Arka plan servisi başlatılamadı: ${e.message}")
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CHANNEL) == null) {
            val ch = NotificationChannel(CHANNEL, "Kombi planı arka planda", NotificationManager.IMPORTANCE_MIN)
            ch.setShowBadge(false)
            nm.createNotificationChannel(ch)
        }
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_kombi)
            .setContentTitle("Kombi planı etkin")
            .setContentText("Zamanlama uygulama kapalıyken de çalışır")
            .setOngoing(true)
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 34) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            else startForeground(NID, n)
        } catch (e: Exception) {
            ActionLog.add(applicationContext, "sistem", null, false, "Ön plan servisi açılamadı: ${e.message}")
            stopSelf()
            return START_NOT_STICKY
        }
        if (!hasActive(this)) { stopSelf(); return START_NOT_STICKY }
        return START_STICKY
    }
}
