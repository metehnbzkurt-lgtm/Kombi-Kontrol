package com.kombikontrol.app

import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequest
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/**
 * Her ~15 dakikada bir emniyet kontrolü:
 *  - Zamanlama alarmları silinmişse yeniden kurar, kaçırılanı telafi eder.
 *  - Kapanma zamanı geçmiş ama kombi hâlâ açık kayıtlıysa kapatma komutunu yeniden gönderir.
 */
class WatchdogWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {

    override fun doWork(): Result {
        val app = applicationContext
        val p = app.getSharedPreferences("kombi", Context.MODE_PRIVATE)

        try { ScheduleAlarmManager.scheduleAll(app, catchUp = true) } catch (_: Exception) {}

        try { DeviceTimers.sync(app) } catch (_: Throwable) {}

        // Alarm gelmiş ama doğrulanamamış komut varsa yeniden deneme alarmı kur (uyku modunda da çalışır).
        CommandRunner.pending(app)?.let { CommandRetry.schedule(app, 10_000L) }

        val offAt = p.getLong("offAt", 0L)
        val now = System.currentTimeMillis()
        if (offAt in 1..(now - 30_000L)) {
            ActionLog.add(app, "bekçi", false, true, "Kapanma zamanı geçmiş, kapatma yeniden gönderiliyor")
            val seq = CommandRunner.nextSeq(app)
            CommandWorker.enqueue(app, false, seq, now, "gecikmiş kapanma", 0)
        }
        return Result.success()
    }

    companion object {
        fun enqueue(context: Context) {
            val req = PeriodicWorkRequest.Builder(WatchdogWorker::class.java, 15, TimeUnit.MINUTES).build()
            WorkManager.getInstance(context.applicationContext)
                .enqueueUniquePeriodicWork("kombi-watchdog", ExistingPeriodicWorkPolicy.KEEP, req)
        }
    }
}
