plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

fun secret(name: String): String = (System.getenv(name) ?: "").replace("\"", "")

android {
    namespace = "com.kombikontrol.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.kombikontrol.app"
        minSdk = 29
        targetSdk = 34
        versionCode = 47
        versionName = "47.0"
        buildConfigField("String", "EWELINK_APP_ID", "\"${secret("EWELINK_APP_ID")}\"")
        buildConfigField("String", "EWELINK_APP_SECRET", "\"${secret("EWELINK_APP_SECRET")}\"")
    }

    // SABİT imza anahtarı: her GitHub derlemesi aynı anahtarla imzalanır, bu yüzden yeni APK
    // eskisinin üzerine "güncelleme" olarak kurulur (imza çakışması olmaz). Anahtarı SİLME / DEĞİŞTİRME.
    signingConfigs {
        create("kombi") {
            storeFile = file("kombi-key.p12")
            storeType = "pkcs12"
            storePassword = "kombikontrol23"
            keyAlias = "kombi"
            keyPassword = "kombikontrol23"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("kombi")
            isDebuggable = false   // hata ayıklama yükü yok: daha akıcı
        }
        getByName("release") {
            signingConfig = signingConfigs.getByName("kombi")
        }
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.11.0")
    implementation("androidx.security:security-crypto:1.1.0")
    implementation("androidx.work:work-runtime:2.9.0")
}
