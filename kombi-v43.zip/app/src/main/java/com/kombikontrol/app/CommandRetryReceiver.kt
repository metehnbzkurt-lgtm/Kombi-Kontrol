package com.kombikontrol.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Başarısız kalan komutu (CommandRunner.pending) yeniden denemek için alarm alıcısı.
 * Tam zamanlı alarm ön plan servisi başlatmaya izin verdiği için uyku modunda da çalışır.
 */
class CommandRetryReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        val w = CommandRunner.pending(app) ?: return
        ActionLog.add(app, "yeniden deneme", w.on, true, "Bekleyen komut yeniden deneniyor")
        try {
            CommandService.start(app, w.on, w.seq, w.at, "yeniden deneme")
        } catch (e: Throwable) {
            ActionLog.add(app, "yeniden deneme", w.on, false, "Servis başlatılamadı: ${e.message}")
            CommandWorker.enqueue(app, w.on, w.seq, w.at, "yeniden deneme", 0)
        }
    }
}

object CommandRetry {
    private const val REQ = 41001

    fun schedule(context: Context, delayMs: Long) {
        val app = context.applicationContext
        val pi = PendingIntent.getBroadcast(
            app, REQ, Intent(app, CommandRetryReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        try { AlarmUtil.set(app, System.currentTimeMillis() + delayMs, pi) } catch (_: Exception) {}
    }
}
