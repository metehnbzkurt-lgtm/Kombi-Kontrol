package com.kombikontrol.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/**
 * Günlük/haftalık zamanlamaları telefonun AlarmManager'ına kurar.
 * - Alarm, tam zamanlı izin varsa tam zamanında çalışır.
 * - Zincir: her alarm, işi yapmadan ÖNCE bir sonrakini kurar (süreç ölse bile zincir kopmaz).
 * - Kaçırılan zamanlamalar (telefon kapalıydı, alarm silindi) 30 dk içinde telafi edilir.
 */
object ScheduleAlarmManager {
    private const val BASE_REQUEST_CODE = 20000
    private const val PREFS_KEY_IDS = "scheduleAlarmIds"
    const val CATCHUP_MS = 30 * 60_000L
    /** Döngü olayları (id ≥ 9e11): son olay bir sonrakine kadar geçerli durumdur, daha uzun telafi edilir. */
    const val CYCLE_CATCHUP_MS = 3 * 60 * 60_000L

    private fun prefs(context: Context) = context.getSharedPreferences("kombi", Context.MODE_PRIVATE)

    private fun requestCode(scheduleId: Long): Int =
        (BASE_REQUEST_CODE + Math.floorMod(scheduleId, 70000L)).toInt()

    private fun pendingIntent(context: Context, scheduleId: Long, on: Boolean, target: Long): PendingIntent {
        val intent = Intent(context, ScheduleReceiver::class.java)
            .putExtra("scheduleId", scheduleId)
            .putExtra("on", on)
            .putExtra("target", target)
        return PendingIntent.getBroadcast(
            context, requestCode(scheduleId), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /** Tüm aktif kayıtları (yeniden) kurar; kaldırılanları iptal eder. catchUp=true: kaçırılanı telafi et. */
    fun scheduleAll(context: Context, catchUp: Boolean) {
        val app = context.applicationContext
        val p = prefs(app)
        val src = try { JSONArray(p.getString("schedules", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        val currentIds = mutableSetOf<Long>()
        val now = System.currentTimeMillis()
        val lastManual = p.getLong("lastManualAt", 0L)
        val missed = mutableListOf<Pair<Long, Boolean>>() // (kaçırılan an, açma mı)

        for (i in 0 until src.length()) {
            val item = src.optJSONObject(i) ?: continue
            val id = item.optLong("id", -1L)
            if (id < 0) continue
            currentIds.add(id)
            if (!item.optBoolean("active", true)) { cancel(app, id); continue }
            scheduleOne(app, item)

            if (catchUp) {
                val parts = item.optString("time", "").split(":")
                val h = parts.getOrNull(0)?.toIntOrNull()
                val m = parts.getOrNull(1)?.toIntOrNull()
                if (h != null && m != null) {
                    val prev = prevTriggerMillis(h, m, item.optString("days", "all"))
                    val lastRun = p.getLong("schRun_$id", 0L)
                    val window = if (id >= 900000000000L) CYCLE_CATCHUP_MS else CATCHUP_MS
                    if (prev > 0 && now - prev in 0..window && lastRun < prev && lastManual < prev && id < prev) {
                        missed.add(prev to (item.optString("action", "ON") == "ON"))
                        p.edit().putLong("schRun_$id", prev).apply()
                    }
                }
            }
        }

        val prevIds = p.getStringSet(PREFS_KEY_IDS, emptySet())
            ?.mapNotNull { it.toLongOrNull() }?.toSet() ?: emptySet()
        for (oldId in prevIds) if (oldId !in currentIds) cancel(app, oldId)
        p.edit().putStringSet(PREFS_KEY_IDS, currentIds.map { it.toString() }.toSet()).apply()

        if (missed.isNotEmpty()) {
            // Birden fazla kaçırılmışsa son durum geçerli olmalı: en son kaçırılanı uygula.
            val last = missed.maxByOrNull { it.first }!!
            ActionLog.add(app, "telafi", last.second, true, "Kaçırılan zamanlama bulundu, uygulanıyor")
            val seq = CommandRunner.nextSeq(app)
            CommandWorker.enqueue(app, last.second, seq, now, "kaçırılan zamanlama", 0)
        }
    }

    /** Tek bir zamanlama kaydının bir sonraki tetiklenme anını hesaplayıp alarmı kurar. */
    fun scheduleOne(context: Context, item: JSONObject) {
        val app = context.applicationContext
        val id = item.optLong("id", -1L); if (id < 0) return
        val parts = item.optString("time", "").split(":")
        val hour = parts.getOrNull(0)?.toIntOrNull() ?: return
        val minute = parts.getOrNull(1)?.toIntOrNull() ?: return
        val daysMode = item.optString("days", "all")
        val on = item.optString("action", "ON") == "ON"

        val target = nextTriggerMillis(hour, minute, daysMode)
        val exact = try {
            AlarmUtil.set(app, target, pendingIntent(app, id, on, target))
        } catch (e: Exception) {
            ActionLog.add(app, "alarm", on, false, "Alarm kurulamadı: ${e.message}")
            false
        }
        prefs(app).edit().putLong("schNext_$id", target).putBoolean("schExact_$id", exact).apply()
    }

    /**
     * Alarm tetiklenince İLK iş olarak çağrılır. true = kayıt hâlâ aktif ve bir sonrakine kuruldu,
     * false = kayıt silinmiş/pasif (eski alarm; komut gönderilmemeli).
     */
    fun rescheduleAfterFire(context: Context, scheduleId: Long): Boolean {
        val app = context.applicationContext
        val src = try { JSONArray(prefs(app).getString("schedules", "[]") ?: "[]") } catch (_: Exception) { return false }
        for (i in 0 until src.length()) {
            val item = src.optJSONObject(i) ?: continue
            if (item.optLong("id", -1L) == scheduleId) {
                return if (item.optBoolean("active", true)) { scheduleOne(app, item); true }
                else { cancel(app, scheduleId); false }
            }
        }
        cancel(app, scheduleId)
        return false
    }

    fun markRun(context: Context, scheduleId: Long, target: Long) {
        prefs(context).edit().putLong("schRun_$scheduleId", target).apply()
    }

    fun cancel(context: Context, scheduleId: Long) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, ScheduleReceiver::class.java)
        val pi = PendingIntent.getBroadcast(
            context, requestCode(scheduleId), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.cancel(pi)
    }

    /** Teşhis: her zamanlamanın bir sonraki kurulu alarmı. */
    fun describe(context: Context): JSONArray {
        val p = prefs(context)
        val out = JSONArray()
        val src = try { JSONArray(p.getString("schedules", "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        for (i in 0 until src.length()) {
            val item = src.optJSONObject(i) ?: continue
            if (!item.optBoolean("active", true)) continue
            val id = item.optLong("id", -1L)
            out.put(
                JSONObject()
                    .put("label", item.optString("label"))
                    .put("action", item.optString("action"))
                    .put("next", p.getLong("schNext_$id", 0L))
                    .put("exact", p.getBoolean("schExact_$id", false))
            )
        }
        return out
    }

    private fun dayOk(dow: Int, daysMode: String): Boolean = when (daysMode) {
        "weekday" -> dow in Calendar.MONDAY..Calendar.FRIDAY
        "weekend" -> dow == Calendar.SUNDAY || dow == Calendar.SATURDAY
        else -> true
    }

    /** "weekday"/"weekend"/"all" + saat:dakika için bir sonraki uygun zamanı (ms) hesaplar. */
    fun nextTriggerMillis(hour: Int, minute: Int, daysMode: String): Long {
        val cal = Calendar.getInstance()
        val now = cal.timeInMillis
        cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        cal.set(Calendar.HOUR_OF_DAY, hour); cal.set(Calendar.MINUTE, minute)
        if (cal.timeInMillis <= now) cal.add(Calendar.DAY_OF_YEAR, 1)
        repeat(8) {
            if (dayOk(cal.get(Calendar.DAY_OF_WEEK), daysMode)) return cal.timeInMillis
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }
        return cal.timeInMillis
    }

    /** Şimdiden önceki en son tetiklenme anı (bulunamazsa 0). */
    fun prevTriggerMillis(hour: Int, minute: Int, daysMode: String): Long {
        val cal = Calendar.getInstance()
        val now = cal.timeInMillis
        cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        cal.set(Calendar.HOUR_OF_DAY, hour); cal.set(Calendar.MINUTE, minute)
        if (cal.timeInMillis > now) cal.add(Calendar.DAY_OF_YEAR, -1)
        repeat(8) {
            if (dayOk(cal.get(Calendar.DAY_OF_WEEK), daysMode)) return cal.timeInMillis
            cal.add(Calendar.DAY_OF_YEAR, -1)
        }
        return 0L
    }
}
