package com.kombikontrol.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

/** Tam zamanlı alarm yardımcıları: izin kontrolü + güvenli kurma. */
object AlarmUtil {

    fun canExact(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        return try { am.canScheduleExactAlarms() } catch (_: Exception) { false }
    }

    /**
     * true = tam zamanlı kuruldu. Önce setAlarmClock: Android bunu gerçek bir saat alarmı sayar,
     * uyku modundan ve marka pil kısıtlamalarından muaftır (en güvenilir yöntem). Olmazsa eski yöntemler.
     */
    fun set(context: Context, atMs: Long, pi: PendingIntent): Boolean {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        try {
            val show = PendingIntent.getActivity(
                context, 0, Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            am.setAlarmClock(AlarmManager.AlarmClockInfo(atMs, show), pi)
            return true
        } catch (_: Exception) {
            // alarm saati kurulamadı; aşağıdaki yedeklere düş
        }
        if (canExact(context)) {
            try {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMs, pi)
                return true
            } catch (_: SecurityException) {
            }
        }
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMs, pi)
        return false
    }
}
