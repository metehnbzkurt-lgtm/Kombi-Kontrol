package com.kombikontrol.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import java.util.concurrent.Executors

/**
 * Alarm anında kombi komutunu GÜVENLE gönderen kısa ömürlü ön plan servisi.
 *
 * Neden: telefon kilitliyken/uyku (Doze) modundayken alarm tetiklenir ama arka plan süreçlerinin
 * interneti kapalıdır; eski 8 sn'lik hızlı deneme başarısız oluyor, yedek iş (WorkManager) ise uyku
 * modunda ertelenip bir sonraki alarmla iptal ediliyordu. Ön plan servisi sürece ağ erişimi ve
 * CPU (wakelock) sağlar; komut başarılı olana dek ~1 dk denenir, olmazsa 90 sn sonrasına yeniden deneme
 * alarmı kurulur (CommandRetryReceiver).
 */
class CommandService : Service() {
    private val exec = Executors.newSingleThreadExecutor()

    companion object {
        private const val CHANNEL = "kombi_komut"
        private const val NID = 4203
        private const val BUDGET_MS = 60_000L   // yeni deneme başlatma süresi (shortService sınırı 3 dk)

        fun start(ctx: Context, on: Boolean, seq: Long, at: Long, origin: String) {
            val i = Intent(ctx, CommandService::class.java)
                .putExtra("on", on).putExtra("seq", seq).putExtra("at", at).putExtra("origin", origin)
            ctx.startForegroundService(i)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun foregroundNotification(): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CHANNEL) == null) {
            val ch = NotificationChannel(CHANNEL, "Kombi komutu gönderiliyor", NotificationManager.IMPORTANCE_LOW)
            ch.setShowBadge(false)
            nm.createNotificationChannel(ch)
        }
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_kombi)
            .setContentTitle("Kombi komutu gönderiliyor")
            .setOngoing(true)
            .build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NID, foregroundNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SHORT_SERVICE)
            } else {
                startForeground(NID, foregroundNotification())
            }
        } catch (e: Exception) {
            ActionLog.add(applicationContext, "servis", null, false, "Ön plan servisi başlatılamadı: ${e.message}")
            stopSelf(startId)
            return START_NOT_STICKY
        }
        val app = applicationContext
        val on = intent?.getBooleanExtra("on", true) ?: true
        val seq = intent?.getLongExtra("seq", 0L) ?: 0L
        val at = intent?.getLongExtra("at", System.currentTimeMillis()) ?: System.currentTimeMillis()
        val origin = intent?.getStringExtra("origin") ?: "arka plan"

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "kombi:komut")
        try { wl.acquire(3 * 60_000L) } catch (_: Exception) {}

        exec.execute {
            try { job(app, on, seq, at, origin) }
            catch (e: Throwable) { ActionLog.add(app, origin, on, false, "Servis hatası: ${e.message}") }
            finally {
                try { if (wl.isHeld) wl.release() } catch (_: Exception) {}
                stopSelf(startId)
            }
        }
        return START_NOT_STICKY
    }

    private fun job(app: Context, on: Boolean, seq: Long, at: Long, origin: String) {
        val p = app.getSharedPreferences("kombi", Context.MODE_PRIVATE)
        fun superseded() = seq > 0 && CommandRunner.currentSeq(app) != seq
        if (superseded() || (seq > 0 && p.getLong("lastOkSeq", -1L) == seq)) return

        val maxAge = if (on) 90 * 60_000L else 3 * 60 * 60_000L
        val t0 = System.currentTimeMillis()
        var n = 0
        while (true) {
            if (superseded()) return
            if (System.currentTimeMillis() - at > maxAge) {
                ActionLog.add(app, origin, on, false, "Vazgeçildi: komut ${maxAge / 60000} dk içinde uygulanamadı")
                Notifier.failure(app, "Kombi komutu uygulanamadı")
                return
            }
            n++
            val o = CommandRunner.run(app, on, "$origin (servis $n)", fast = false, seq = seq, timeoutOverride = 6000)
            if (o.ok) {
                if (!superseded()) CommandWorker.cancel(app)
                Notifier.announce(app, on)
                return
            }
            if (System.currentTimeMillis() - t0 + 5000 > BUDGET_MS) break
            try { Thread.sleep(4000) } catch (_: InterruptedException) { break }
        }
        // Bu turda olmadı: 90 sn sonra yeniden deneme alarmı (uyku modunda da çalışır).
        if (!superseded()) CommandRetry.schedule(app, 90_000L)
    }

    /** Android 14+: shortService 3 dk dolunca sistem çağırır; servisi hemen durdur. */
    override fun onTimeout(startId: Int) {
        stopSelf(startId)
    }

    override fun onDestroy() {
        exec.shutdown()
        super.onDestroy()
    }
}
