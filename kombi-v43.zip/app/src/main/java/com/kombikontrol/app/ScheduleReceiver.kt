package com.kombikontrol.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Günlük/haftalık zamanlama alarmı tetiklenince:
 *  0) alarmın alındığını kayda yazar (teşhis: alarm hiç gelmiyorsa bu satır da olmaz),
 *  1) bir sonraki alarmı kurar (zincir hiçbir koşulda kopmaz),
 *  2) komutu gönderir ve doğrular (CommandDispatcher).
 */
class ScheduleReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        val scheduleId = intent.getLongExtra("scheduleId", -1L)
        val on = intent.getBooleanExtra("on", true)
        val target = intent.getLongExtra("target", System.currentTimeMillis())
        val lateSec = (System.currentTimeMillis() - target) / 1000
        ActionLog.add(app, "zamanlama", on, true, "Alarm alındı (gecikme ${lateSec} sn)")
        if (scheduleId < 0) return

        try {
            val active = ScheduleAlarmManager.rescheduleAfterFire(app, scheduleId)
            if (!active) {
                ActionLog.add(app, "zamanlama", on, false, "Kayıt silinmiş/pasif, komut gönderilmedi")
                return
            }
            ScheduleAlarmManager.markRun(app, scheduleId, target)
            CommandDispatcher.fromReceiver(app, on, "zamanlama", goAsync())
        } catch (e: Throwable) {
            ActionLog.add(app, "zamanlama", on, false, "Alarm işlenirken hata: ${e.javaClass.simpleName} ${e.message}")
        }
    }
}
