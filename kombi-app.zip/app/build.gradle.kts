plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

fun secret(name: String): String = (System.getenv(name) ?: "").replace("\"", "")

android {
    namespace = "com.kombikontrol.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.kombikontrol.app"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        buildConfigField("String", "EWELINK_APP_ID", "\"${secret("EWELINK_APP_ID")}\"")
        buildConfigField("String", "EWELINK_APP_SECRET", "\"${secret("EWELINK_APP_SECRET")}\"")
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.11.0")
}
