package com.kombikontrol.app

import android.app.Activity
import android.content.Context
import android.os.Build
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import java.util.concurrent.Executors

/** HTML arayüzü (window.KombiNative) ile eWeLink arasındaki köprü. */
class KombiBridge(private val activity: Activity, private val web: WebView) {

    private val prefs = activity.getSharedPreferences("kombi", Context.MODE_PRIVATE)
    private val io = Executors.newSingleThreadExecutor()
    private val client = EweLinkClient(BuildConfig.EWELINK_APP_ID, BuildConfig.EWELINK_APP_SECRET)

    private var schedulesJson: String = prefs.getString("schedules", "[]") ?: "[]"
    private var offAtMs: Long = prefs.getLong("offAt", 0L)

    init {
        client.region = prefs.getString("region", "eu") ?: "eu"
    }

    // ---------- JS'e geri bildirim ----------
    private fun js(code: String) = activity.runOnUiThread { web.evaluateJavascript(code, null) }
    private fun result(ok: Boolean, msg: String) =
        js("window.onNativeResult && window.onNativeResult($ok, ${JSONObject.quote(msg)})")

    // ---------- Yardımcılar ----------
    private fun deviceId(): String {
        val d = prefs.getString("deviceId", "") ?: ""
        if (d.isEmpty()) throw Exception("Cihaz ID girilmemiş (Ayarlar > eWeLink Hesabı).")
        return d
    }

    private fun login() {
        val email = prefs.getString("email", "") ?: ""
        val pass = prefs.getString("password", "") ?: ""
        if (email.isEmpty() || pass.isEmpty()) throw Exception("E-posta/şifre girilmemiş (Ayarlar > eWeLink Hesabı).")
        client.login(email, pass)
        prefs.edit().putString("region", client.region).apply()
    }

    private fun <T> withLogin(block: () -> T): T {
        if (client.token == null) login()
        return try {
            block()
        } catch (e: EweLinkClient.AuthException) {
            client.token = null
            login()
            block()
        }
    }

    private fun uuidOf(key: String) = UUID.nameUUIDFromBytes(("kombi-$key").toByteArray()).toString()

    /** Yerel saat -> UTC cron (eWeLink tekrarlayan zamanlayıcılar UTC çalışır). Haftanın günü 0=Pazar. */
    private fun repeatTimer(s: JSONObject): JSONObject {
        val parts = s.getString("time").split(":")
        val offsetMin = TimeZone.getDefault().getOffset(System.currentTimeMillis()) / 60000
        var total = parts[0].toInt() * 60 + parts[1].toInt() - offsetMin
        var dayShift = 0
        while (total < 0) { total += 1440; dayShift-- }
        while (total >= 1440) { total -= 1440; dayShift++ }
        val days = when (s.optString("days", "all")) {
            "weekday" -> listOf(1, 2, 3, 4, 5)
            "weekend" -> listOf(0, 6)
            else -> (0..6).toList()
        }
        val utcDays = days.map { ((it + dayShift) % 7 + 7) % 7 }.sorted().joinToString(",")
        val cron = "${total % 60} ${total / 60} * * $utcDays"
        return JSONObject()
            .put("enabled", 1)
            .put("mId", uuidOf("s-" + s.opt("id").toString()))
            .put("type", "repeat")
            .put("at", cron)
            .put("coolkit_timer_type", "repeat")
            .put("do", JSONObject().put("switch", if (s.optString("action") == "ON") "on" else "off"))
    }

    /** Geri sayım / güvenlik kapatması: belirli bir anda kombiyi kapat. */
    private fun onceTimer(ms: Long): JSONObject {
        val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US)
        fmt.timeZone = TimeZone.getTimeZone("UTC")
        return JSONObject()
            .put("enabled", 1)
            .put("mId", uuidOf("countdown"))
            .put("type", "once")
            .put("at", fmt.format(Date(ms)))
            .put("coolkit_timer_type", "delay")
            .put("do", JSONObject().put("switch", "off"))
    }

    private fun pushTimers() {
        val arr = JSONArray()
        val src = JSONArray(schedulesJson)
        for (i in 0 until src.length()) {
            val s = src.getJSONObject(i)
            if (s.optBoolean("active", true)) arr.put(repeatTimer(s))
        }
        if (offAtMs > System.currentTimeMillis()) arr.put(onceTimer(offAtMs))
        val id = deviceId()
        withLogin { client.setParams(id, JSONObject().put("timers", arr)) }
    }

    // ---------- JS'ten çağrılanlar ----------
    @JavascriptInterface
    fun getConfig(): String = JSONObject()
        .put("email", prefs.getString("email", ""))
        .put("region", prefs.getString("region", "eu"))
        .put("deviceId", prefs.getString("deviceId", ""))
        .put("hasPassword", !prefs.getString("password", "").isNullOrEmpty())
        .put("keysOk", client.configured)
        .toString()

    @JavascriptInterface
    fun saveConfig(email: String, password: String, region: String, deviceId: String) {
        val e = prefs.edit()
            .putString("email", email)
            .putString("region", region)
            .putString("deviceId", deviceId)
        if (password.isNotEmpty()) e.putString("password", password)
        e.apply()
        client.region = region
        client.token = null
    }

    @JavascriptInterface
    fun getStatus() {
        io.execute {
            try {
                val id = deviceId()
                val on = withLogin { client.getSwitch(id) }
                js("window.onNativeStatus && window.onNativeStatus($on)")
            } catch (e: Exception) {
                result(false, e.message ?: "Bilinmeyen hata")
            }
        }
    }

    /** autoOffMin > 0 ise cihaz içinde o kadar dakika sonra kapanma zamanlayıcısı da yazılır. */
    @JavascriptInterface
    fun setSwitch(on: Boolean, autoOffMin: Int) {
        io.execute {
            try {
                val id = deviceId()
                withLogin { client.setParams(id, JSONObject().put("switch", if (on) "on" else "off")) }
                offAtMs = if (on && autoOffMin > 0) System.currentTimeMillis() + autoOffMin * 60000L else 0L
                prefs.edit().putLong("offAt", offAtMs).apply()
                pushTimers()
                result(true, "Tamam")
            } catch (e: Exception) {
                result(false, e.message ?: "Bilinmeyen hata")
            }
        }
    }

    @JavascriptInterface
    fun syncSchedules(json: String) {
        schedulesJson = json
        prefs.edit().putString("schedules", json).apply()
        io.execute {
            try {
                pushTimers()
                result(true, "Zamanlamalar cihaza yazıldı")
            } catch (e: Exception) {
                result(false, e.message ?: "Bilinmeyen hata")
            }
        }
    }

    @Suppress("DEPRECATION")
    @JavascriptInterface
    fun setTheme(dark: Boolean) {
        activity.runOnUiThread {
            val c = if (dark) 0xFF06090F.toInt() else 0xFFEEF1F7.toInt()
            activity.window.statusBarColor = c
            activity.window.navigationBarColor = c
            web.setBackgroundColor(c)
            var f = activity.window.decorView.systemUiVisibility
            f = if (dark) f and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv() else f or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            if (Build.VERSION.SDK_INT >= 26) {
                f = if (dark) f and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv() else f or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            }
            activity.window.decorView.systemUiVisibility = f
        }
    }
}
