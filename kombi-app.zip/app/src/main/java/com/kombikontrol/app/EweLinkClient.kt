package com.kombikontrol.app

import android.util.Base64
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * eWeLink (CoolKit) v2 REST istemcisi.
 * NOT: Developer onayı olmadan test edilemedi; ilk gerçek denemede hata mesajlarına göre ayarlanması gerekebilir.
 */
class EweLinkClient(private val appId: String, private val appSecret: String) {

    class AuthException(msg: String) : Exception(msg)

    var region: String = "eu"
    var token: String? = null

    val configured: Boolean get() = appId.isNotEmpty() && appSecret.isNotEmpty()

    private fun sign(body: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(appSecret.toByteArray(), "HmacSHA256"))
        return Base64.encodeToString(mac.doFinal(body.toByteArray()), Base64.NO_WRAP)
    }

    private fun request(method: String, path: String, body: String?, auth: String): JSONObject {
        val conn = URL("https://$region-apia.coolkit.cc$path").openConnection() as HttpURLConnection
        conn.requestMethod = method
        conn.connectTimeout = 15000
        conn.readTimeout = 15000
        conn.setRequestProperty("X-CK-Appid", appId)
        conn.setRequestProperty("X-CK-Nonce", UUID.randomUUID().toString().replace("-", "").take(8))
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("Authorization", auth)
        if (body != null) {
            conn.doOutput = true
            conn.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else (conn.errorStream ?: conn.inputStream)
        val text = stream.bufferedReader().use { it.readText() }
        return JSONObject(text)
    }

    private fun check(r: JSONObject): JSONObject {
        val err = r.optInt("error", -1)
        if (err == 0) return r
        val msg = "eWeLink hata $err: ${r.optString("msg")}"
        if (err == 401 || err == 402 || err == 406) throw AuthException(msg)
        throw Exception(msg)
    }

    fun login(email: String, password: String) {
        if (!configured) throw Exception("App ID/Secret derlemeye eklenmemiş (GitHub Secrets).")
        repeat(2) {
            val body = JSONObject()
                .put("email", email)
                .put("password", password)
                .put("countryCode", "+90")
                .toString()
            val r = request("POST", "/v2/user/login", body, "Sign " + sign(body))
            val err = r.optInt("error", -1)
            if (err == 0) {
                token = r.getJSONObject("data").getString("at")
                return
            }
            if (err == 10004) {
                val reg = r.optJSONObject("data")?.optString("region") ?: ""
                if (reg.isNotEmpty() && reg != region) {
                    region = reg
                    return@repeat
                }
            }
            throw Exception("Giriş hatası ($err): ${r.optString("msg")}")
        }
        throw Exception("Giriş başarısız (bölge bulunamadı).")
    }

    fun getSwitch(deviceId: String): Boolean {
        val r = check(request("GET", "/v2/device/thing/status?type=1&id=$deviceId&params=switch", null, "Bearer $token"))
        return r.getJSONObject("data").getJSONObject("params").optString("switch") == "on"
    }

    fun setParams(deviceId: String, params: JSONObject) {
        val body = JSONObject().put("type", 1).put("id", deviceId).put("params", params).toString()
        check(request("POST", "/v2/device/thing/status", body, "Bearer $token"))
    }
}
