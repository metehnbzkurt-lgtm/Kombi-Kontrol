package com.kombikontrol.app

import android.util.Base64
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * eWeLink (CoolKit) v2 REST istemcisi — OAuth2.0.
 * NOT: Developer onayı olmadan test edilemedi; imzalama (sign) adımı dokümantasyona göre
 * yazıldı, gerçek App ID/Secret gelince doğrulanması/düzeltilmesi gerekebilir.
 * Resmi dokümantasyon: https://coolkit-technologies.github.io/eWeLink-API/#/en/OAuth2.0
 *
 * Email/şifre bu sınıfta YOK. Kullanıcı eWeLink'in kendi tarayıcı sayfasında giriş yapar,
 * buraya sadece dönen "authorization code" gelir, o da token'a çevrilir.
 */
class EweLinkClient(private val appId: String, private val appSecret: String) {

    class AuthException(msg: String) : Exception(msg)

    var region: String = "eu"
    var accessToken: String? = null
    var refreshToken: String? = null

    val configured: Boolean get() = appId.isNotEmpty() && appSecret.isNotEmpty()

    private fun sign(body: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(appSecret.toByteArray(), "HmacSHA256"))
        return Base64.encodeToString(mac.doFinal(body.toByteArray()), Base64.NO_WRAP)
    }

    /** Tarayıcıda açılacak eWeLink giriş sayfası adresi. */
    fun buildAuthorizeUrl(redirectUrl: String, state: String): String {
        val seq = System.currentTimeMillis().toString()
        val authPayload = JSONObject().put("appId", appId).put("seq", seq).toString()
        val authorization = sign(authPayload)
        val params = listOf(
            "state" to state,
            "clientId" to appId,
            "authorization" to authorization,
            "seq" to seq,
            "redirectUrl" to redirectUrl,
            "grantType" to "authorization_code",
            "showQRCode" to "false"
        ).joinToString("&") { (k, v) -> "$k=" + java.net.URLEncoder.encode(v, "UTF-8") }
        return "https://c2ccdn.coolkit.cc/oauth/index.html?$params"
    }

    private fun request(method: String, path: String, body: String?, auth: String, apiRegion: String = region): JSONObject {
        val conn = URL("https://$apiRegion-apia.coolkit.cc$path").openConnection() as HttpURLConnection
        conn.requestMethod = method
        conn.connectTimeout = 15000
        conn.readTimeout = 15000
        conn.setRequestProperty("X-CK-Appid", appId)
        conn.setRequestProperty("X-CK-Nonce", UUID.randomUUID().toString().replace("-", "").take(8))
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("Authorization", auth)
        if (body != null) {
            conn.doOutput = true
            conn.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else (conn.errorStream ?: conn.inputStream)
        val text = stream.bufferedReader().use { it.readText() }
        return JSONObject(text)
    }

    private fun check(r: JSONObject): JSONObject {
        val err = r.optInt("error", -1)
        if (err == 0) return r
        val msg = "eWeLink hata $err: ${r.optString("msg")}"
        if (err == 401 || err == 402 || err == 406) throw AuthException(msg)
        throw Exception(msg)
    }

    /** eWeLink'ten dönen "code"u gerçek access/refresh token ile değiştirir. */
    fun exchangeCode(code: String, redirectUrl: String, codeRegion: String?) {
        if (!configured) throw Exception("App ID/Secret derlemeye eklenmemiş (GitHub Secrets).")
        val body = JSONObject()
            .put("code", code)
            .put("redirectUrl", redirectUrl)
            .put("grantType", "authorization_code")
            .toString()
        val r = request("POST", "/v2/user/oauth/token", body, "Sign " + sign(body), codeRegion ?: region)
        check(r)
        val data = r.getJSONObject("data")
        accessToken = data.getString("accessToken")
        refreshToken = data.getString("refreshToken")
        if (codeRegion != null) region = codeRegion
    }

    /** accessToken süresi dolunca refreshToken ile yenisini alır. */
    fun doRefresh() {
        val rt = refreshToken ?: throw AuthException("Oturum yok, yeniden giriş yap.")
        val body = JSONObject().put("rt", rt).toString()
        val r = request("POST", "/v2/user/refresh", body, "Sign " + sign(body))
        check(r)
        val data = r.getJSONObject("data")
        accessToken = data.getString("at")
        refreshToken = data.optString("rt", rt)
    }

    fun getSwitch(deviceId: String): Boolean {
        val r = check(request("GET", "/v2/device/thing/status?type=1&id=$deviceId&params=switch", null, "Bearer $accessToken"))
        return r.getJSONObject("data").getJSONObject("params").optString("switch") == "on"
    }

    fun setParams(deviceId: String, params: JSONObject) {
        val body = JSONObject().put("type", 1).put("id", deviceId).put("params", params).toString()
        check(request("POST", "/v2/device/thing/status", body, "Bearer $accessToken"))
    }
}
