// Tek seferlik: cihaz ID ve anahtarını (devicekey) eWeLink hesabından okur.
// Çalıştır (bilgisayarda, internet açıkken):
//   cd tools && npm install
//   EWELINK_EMAIL=mail@ornek.com EWELINK_PASSWORD=sifre node get-key.js
const ewelink = require('ewelink-api');

(async () => {
  const { EWELINK_EMAIL, EWELINK_PASSWORD } = process.env;
  if (!EWELINK_EMAIL || !EWELINK_PASSWORD) {
    console.error('EWELINK_EMAIL ve EWELINK_PASSWORD gerekli.');
    process.exit(1);
  }
  const connection = new ewelink({ email: EWELINK_EMAIL, password: EWELINK_PASSWORD, region: 'eu' });
  const devices = await connection.getDevices();
  if (!Array.isArray(devices)) {
    console.error('Cihazlar alınamadı:', devices);
    process.exit(1);
  }
  devices.forEach(d => {
    console.log('---------------------------');
    console.log('Ad         :', d.name);
    console.log('Cihaz ID   :', d.deviceid);
    console.log('Anahtar    :', d.devicekey);
  });
})();
