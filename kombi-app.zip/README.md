# Kombi Kontrol (Android)

HTML arayüz (`app/src/main/assets/index.html`) bir WebView içinde açılır; Kotlin tarafı eWeLink ile konuşur.

## Derleme (GitHub)
1. Bu dosyaların hepsini (`.github` klasörü dahil) repoya yükle.
2. Repo > Settings > Secrets and variables > Actions: `EWELINK_APP_ID` ve `EWELINK_APP_SECRET` ekle (Developer onayı gelince).
3. Actions > Build APK > çalıştır. Bitince **KombiKontrol-APK** çıktısından `app-debug.apk` indir.

`.github/workflows/build.yml` yüklenmezse: Add file > Create new file, adı `.github/workflows/build.yml`, içeriği yapıştır.

## Uygulamada
Ayarlar (⚙️) > eWeLink Hesabı: e-posta, şifre, bölge, cihaz ID gir > "Kaydet ve Bağlan".
Zamanlamalar, geri sayım ve 4 saat güvenlik kapatması cihaza yazılır; uygulama kapalıyken de çalışır.

## Not
eWeLink bölümü (EweLinkClient.kt / KombiBridge.kt) Developer onayı olmadan test edilemedi. Hata olursa mesaj uygulamada görünür.
