# Kombi Kontrol (APK)

## 1) Cihaz anahtarını al (tek sefer, bilgisayarda)
    cd tools && npm install
    EWELINK_EMAIL=... EWELINK_PASSWORD=... node get-key.js
Çıktıdaki **Cihaz ID** ve **Anahtar** değerlerini not al.

## 2) Cihaza sabit IP ver
Router ayarlarından Sonoff'un IP adresini sabitle (DHCP rezervasyonu).

## 3) APK'yı GitHub'da derle
1. Bu klasörü yeni bir GitHub deposuna yükle (main dalı).
2. Depoda **Actions → Build APK** çalışır (ya da "Run workflow").
3. Bitince çalıştırmanın altındaki **kombi-kontrol-apk** dosyasını indir, zip'ten çıkan `app-debug.apk`'yı telefona kur.

## 4) Uygulamada
⚙️ Ayarlar → IP, Cihaz ID, Cihaz anahtarı gir. Telefon ve cihaz aynı Wi-Fi'da olmalı.
