package com.kombikontrol.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Telefon yeniden başlatılınca (sistem alarmları siler) bekleyen otomatik kapanma
 * varsa alarmı yeniden kurar. Kombi zaten fiziksel olarak açık kalmaya devam eder,
 * bu receiver sadece "kapatma hatırlatıcısını" hayatta tutar.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val appContext = context.applicationContext
        val prefs = context.getSharedPreferences("kombi", Context.MODE_PRIVATE)
        val offAtMs = prefs.getLong("offAt", 0L)
        if (offAtMs > System.currentTimeMillis()) {
            AutoOffScheduler.schedule(appContext, offAtMs)
        }
        // Günlük/haftalık zamanlamalar: sistem reboot'ta tüm alarmları sildiği için yeniden kurulmalı.
        ScheduleAlarmManager.scheduleAll(appContext)
    }
}
