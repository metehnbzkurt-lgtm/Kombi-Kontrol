package com.kombikontrol.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.util.concurrent.Executors

/**
 * AutoOffScheduler'ın kurduğu alarm süresi dolunca sistem tarafından tetiklenir.
 * Ses/titreşim/bildirim YOK: arka planda eWeLink'e kapat komutu gönderir ve biter.
 */
class AutoOffReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val appContext = context.applicationContext
        val pending = goAsync()
        Executors.newSingleThreadExecutor().execute {
            try {
                AutoOffWorker.turnOff(appContext)
            } catch (e: Exception) {
                // Sessiz başarısızlık: uygulama tekrar açıldığında gerçek durum cihazdan okunur.
            } finally {
                pending.finish()
            }
        }
    }
}
