package com.kombikontrol.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent

/**
 * Kombiyi belirtilen zamanda sessizce kapatacak sistem alarmını kurar/iptal eder.
 * Ses/titreşim/ekran YOK: sadece arka planda AutoOffReceiver'ı tetikler.
 * setAndAllowWhileIdle, Doze/uyku modunda da (özel izin gerektirmeden) teslim edilir;
 * birkaç dakikalık sapma olabilir ama ekstra kullanıcı izni istemez.
 */
object AutoOffScheduler {
    private const val REQUEST_CODE = 1001

    private fun pendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, AutoOffReceiver::class.java)
        return PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun schedule(context: Context, targetAtMs: Long) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        try {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, targetAtMs, pendingIntent(context))
        } catch (e: SecurityException) {
            // Bazı OEM'lerde kısıtlanmış olabilir; sessizce yok say, bulut zamanlayıcı (varsa) devrede kalır.
        }
    }

    fun cancel(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pendingIntent(context))
    }
}
