package com.kombikontrol.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/**
 * "Zamanlamalar" (günlük/haftalık otomasyon) listesini cihaz bulutuna değil,
 * telefonun kendi AlarmManager'ına kurar. Böylece cihaz 3. parti zamanlayıcı
 * kabul etmese bile (eWeLink hata 4002) otomasyon telefon üzerinden çalışır.
 * Her alarm tetiklendiğinde komutu gönderir ve bir sonraki uygun günü/saati
 * otomatik olarak yeniden kurar.
 */
object ScheduleAlarmManager {
    private const val BASE_REQUEST_CODE = 20000
    private const val PREFS_KEY_IDS = "scheduleAlarmIds"

    private fun prefs(context: Context) = context.getSharedPreferences("kombi", Context.MODE_PRIVATE)

    private fun requestCode(scheduleId: Long): Int =
        (BASE_REQUEST_CODE + Math.floorMod(scheduleId, 70000L)).toInt()

    private fun pendingIntent(context: Context, scheduleId: Long, on: Boolean): PendingIntent {
        val intent = Intent(context, ScheduleReceiver::class.java)
            .putExtra("scheduleId", scheduleId)
            .putExtra("on", on)
        return PendingIntent.getBroadcast(
            context, requestCode(scheduleId), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    /** schedulesJson'daki tüm aktif kayıtları (yeniden) kurar; kaldırılanları iptal eder. */
    fun scheduleAll(context: Context) {
        val src = JSONArray(prefs(context).getString("schedules", "[]") ?: "[]")
        val currentIds = mutableSetOf<Long>()
        for (i in 0 until src.length()) {
            val item = src.optJSONObject(i) ?: continue
            val id = item.optLong("id", -1L)
            if (id < 0) continue
            currentIds.add(id)
            if (item.optBoolean("active", true)) scheduleOne(context, item) else cancel(context, id)
        }
        val prevIds = prefs(context).getStringSet(PREFS_KEY_IDS, emptySet())
            ?.mapNotNull { it.toLongOrNull() }?.toSet() ?: emptySet()
        for (oldId in prevIds) if (oldId !in currentIds) cancel(context, oldId)
        prefs(context).edit().putStringSet(PREFS_KEY_IDS, currentIds.map { it.toString() }.toSet()).apply()
    }

    /** Tek bir zamanlama kaydının bir sonraki tetiklenme anını hesaplayıp alarmı kurar. */
    fun scheduleOne(context: Context, item: JSONObject) {
        val id = item.optLong("id", -1L); if (id < 0) return
        val parts = item.optString("time", "").split(":")
        val hour = parts.getOrNull(0)?.toIntOrNull() ?: return
        val minute = parts.getOrNull(1)?.toIntOrNull() ?: return
        val daysMode = item.optString("days", "all")
        val on = item.optString("action", "ON") == "ON"

        val target = nextTriggerMillis(hour, minute, daysMode)
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pendingIntent(context, id, on)
        try {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, target, pi)
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, target, pi)
        }
    }

    /** ScheduleReceiver bir alarmı işledikten sonra aynı kaydı bir sonraki zamana kurmak için çağırır. */
    fun rescheduleAfterFire(context: Context, scheduleId: Long) {
        val src = JSONArray(prefs(context).getString("schedules", "[]") ?: "[]")
        for (i in 0 until src.length()) {
            val item = src.optJSONObject(i) ?: continue
            if (item.optLong("id", -1L) == scheduleId) {
                if (item.optBoolean("active", true)) scheduleOne(context, item) else cancel(context, scheduleId)
                return
            }
        }
    }

    fun cancel(context: Context, scheduleId: Long) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, ScheduleReceiver::class.java)
        val pi = PendingIntent.getBroadcast(
            context, requestCode(scheduleId), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.cancel(pi)
    }

    /** "weekday"/"weekend"/"all" + saat:dakika için bir sonraki uygun zamanı (ms) hesaplar. */
    private fun nextTriggerMillis(hour: Int, minute: Int, daysMode: String): Long {
        val cal = Calendar.getInstance()
        val now = cal.timeInMillis
        cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        cal.set(Calendar.HOUR_OF_DAY, hour); cal.set(Calendar.MINUTE, minute)
        if (cal.timeInMillis <= now) cal.add(Calendar.DAY_OF_YEAR, 1)
        repeat(8) {
            val dow = cal.get(Calendar.DAY_OF_WEEK)
            val ok = when (daysMode) {
                "weekday" -> dow in Calendar.MONDAY..Calendar.FRIDAY
                "weekend" -> dow == Calendar.SUNDAY || dow == Calendar.SATURDAY
                else -> true
            }
            if (ok) return cal.timeInMillis
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }
        return cal.timeInMillis
    }
}
