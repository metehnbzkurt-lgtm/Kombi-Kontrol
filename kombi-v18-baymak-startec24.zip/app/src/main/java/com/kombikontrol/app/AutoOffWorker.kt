package com.kombikontrol.app

import android.content.Context

/**
 * Activity/WebView olmadan (AlarmManager tetiklendiğinde) eWeLink'e aç/kapat
 * komutu gönderen bağımsız mantık. Hem "süre sonunda kapat" (AutoOffScheduler)
 * hem de "günlük zamanlamalar" (ScheduleAlarmManager) burayı kullanır.
 */
object AutoOffWorker {

    /** Süre sonunda kapatma: başarılı olursa kayıtlı offAt'i sıfırlar. */
    fun turnOff(context: Context) {
        if (setSwitch(context, false)) {
            val prefs = context.getSharedPreferences("kombi", Context.MODE_PRIVATE)
            prefs.edit().putLong("offAt", 0L).apply()
        }
    }

    /** Genel aç/kapat komutu. Token yenileme ve bölge denemesi dahildir. true = başarılı. */
    fun setSwitch(context: Context, on: Boolean): Boolean {
        val prefs = context.getSharedPreferences("kombi", Context.MODE_PRIVATE)
        val secure = SecureStore.get(context)

        val deviceId = prefs.getString("deviceId", "") ?: ""
        if (deviceId.isEmpty()) return false
        val outlet = prefs.getInt("outlet", 0)

        val client = EweLinkClient(BuildConfig.EWELINK_APP_ID, BuildConfig.EWELINK_APP_SECRET)
        if (!client.configured) return false
        client.region = prefs.getString("region", "eu") ?: "eu"
        client.accessToken = secure.getString("accessToken", null)
        client.refreshToken = secure.getString("refreshToken", null)
        if (client.accessToken == null && client.refreshToken == null) return false

        fun persistTokens() {
            secure.edit()
                .putString("accessToken", client.accessToken)
                .putString("refreshToken", client.refreshToken)
                .apply()
            prefs.edit().putString("region", client.region).apply()
        }

        fun tryCommand(): Boolean = try {
            client.setSwitch(deviceId, outlet, on)
            true
        } catch (e: EweLinkClient.AuthException) {
            false
        }

        if (client.accessToken == null) {
            try { client.doRefresh() } catch (e: Exception) { return false }
        }

        if (tryCommand()) { persistTokens(); return true }

        try {
            client.doRefresh()
            if (tryCommand()) { persistTokens(); return true }
        } catch (e: Exception) {
            // yenileme olmadı, bölge denemesine geç
        }

        val original = client.region
        for (r in listOf("as", "eu", "us", "cn")) {
            if (r == original) continue
            client.region = r
            if (tryCommand()) { persistTokens(); return true }
        }
        client.region = original
        return false
    }
}
