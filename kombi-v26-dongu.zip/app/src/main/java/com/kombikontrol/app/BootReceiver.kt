package com.kombikontrol.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Reboot, uygulama güncellemesi, saat/saat dilimi değişimi veya tam alarm izni değişimi
 * sistem alarmlarını silebilir: hepsini yeniden kurar. Reboot'ta kaçırılanı telafi eder.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        val app = context.applicationContext
        val prefs = app.getSharedPreferences("kombi", Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()

        val offAt = prefs.getLong("offAt", 0L)
        if (offAt > now) {
            AutoOffScheduler.schedule(app, offAt)
        } else if (offAt > 0L) {
            // Telefon kapalıyken kapanma zamanı geçti: hemen kapat.
            val seq = CommandRunner.nextSeq(app)
            CommandWorker.enqueue(app, false, seq, now, "kapanma (gecikmiş)", 0)
        }

        ScheduleAlarmManager.scheduleAll(app, catchUp = action == Intent.ACTION_BOOT_COMPLETED)
        try { LoopModeManager.restore(app) } catch (_: Exception) {}
        WatchdogWorker.enqueue(app)
        ActionLog.add(app, "sistem", null, true, "Alarmlar yeniden kuruldu ($action)")
    }
}
