package com.kombikontrol.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Döngü faz değişim alarmı: açık → kapalı veya kapalı → açık.
 * Komut CommandWorker üzerinden doğrulanarak gönderilir.
 */
class LoopReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        if (!LoopModeManager.isActive(app)) return
        ActionLog.add(app, "döngü", null, true, "Faz alarmı alındı")
        LoopModeManager.onAlarm(app)
    }
}
