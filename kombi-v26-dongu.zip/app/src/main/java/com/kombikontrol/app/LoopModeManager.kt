package com.kombikontrol.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import org.json.JSONObject

/**
 * Açık/Kapalı döngü modu: belirli süre yanar, belirli süre bekler, tekrarlar.
 * Telefon AlarmManager ile çalışır; uygulama kapalıyken de faz değişimi yapılır.
 * Güvenlik: tek ON fazı en fazla CommandRunner.SAFETY_MS (4 saat).
 */
object LoopModeManager {
    private const val REQUEST_CODE = 30001
    private const val PREFS = "kombi"

    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun pendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, LoopReceiver::class.java)
        return PendingIntent.getBroadcast(
            context.applicationContext, REQUEST_CODE, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun isActive(context: Context): Boolean =
        prefs(context.applicationContext).getBoolean("loopActive", false)

    /** Döngüyü başlatır (veya süreleri güncelleyip yeniden kurar). onMin/offMin: 5–120 dk. */
    fun start(context: Context, onMin: Int, offMin: Int, band: Int = -1, mode: String = "") {
        val app = context.applicationContext
        val onM = onMin.coerceIn(5, 120)
        val offM = offMin.coerceIn(5, 120)
        val now = System.currentTimeMillis()
        // ON fazı güvenlik süresini aşmasın
        val onMs = minOf(onM * 60_000L, CommandRunner.SAFETY_MS)
        val phaseEnd = now + onMs

        val ed = prefs(app).edit()
            .putBoolean("loopActive", true)
            .putInt("loopOnMin", onM)
            .putInt("loopOffMin", offM)
            .putString("loopPhase", "on")
            .putLong("loopPhaseEnd", phaseEnd)
            .putLong("loopStartedAt", now)
        if (band in 0..3) ed.putInt("loopBand", band)
        if (mode == "day" || mode == "night") ed.putString("loopMode", mode)
        ed.apply()

        // Tek seferlik kapanma alarmı ile çakışmayı önle; döngü kendi faz alarmını kullanır
        AutoOffScheduler.cancel(app)

        scheduleAlarm(app, phaseEnd)

        // Hemen ON fazını başlat; offAt = faz sonu (güvenlik + UI)
        val seq = CommandRunner.nextSeq(app)
        CommandWorker.enqueue(app, true, seq, now, "döngü (başlat)", 0, phaseEnd)

        ActionLog.add(app, "döngü", true, true, "Döngü başladı: $onM dk açık / $offM dk kapalı")
    }

    fun stop(context: Context) {
        val app = context.applicationContext
        if (!isActive(app)) return
        cancelAlarm(app)
        prefs(app).edit()
            .putBoolean("loopActive", false)
            .putString("loopPhase", "off")
            .putLong("loopPhaseEnd", 0L)
            .apply()
        ActionLog.add(app, "döngü", null, true, "Döngü durduruldu")
    }

    /** Süreler değişince (döngü çalışırken) kalan fazı bozmadan yeni süreleri kaydeder;
     * bir sonraki faz geçişinde yeni süreler kullanılır. İstenirse mevcut fazı da yeniden kurar. */
    fun updateTimes(context: Context, onMin: Int, offMin: Int) {
        val app = context.applicationContext
        val onM = onMin.coerceIn(5, 120)
        val offM = offMin.coerceIn(5, 120)
        prefs(app).edit()
            .putInt("loopOnMin", onM)
            .putInt("loopOffMin", offM)
            .apply()
    }

    /** Boot / izin değişimi: aktif döngüyü yeniden kurar veya kaçırılan fazı uygular. */
    fun restore(context: Context) {
        val app = context.applicationContext
        val p = prefs(app)
        if (!p.getBoolean("loopActive", false)) return

        val now = System.currentTimeMillis()
        var phaseEnd = p.getLong("loopPhaseEnd", 0L)
        val phase = p.getString("loopPhase", "on") ?: "on"

        if (phaseEnd <= 0L) {
            // Bozuk durum: yeniden ON fazı başlat
            val onM = p.getInt("loopOnMin", 40).coerceIn(5, 120)
            phaseEnd = now + minOf(onM * 60_000L, CommandRunner.SAFETY_MS)
            p.edit().putString("loopPhase", "on").putLong("loopPhaseEnd", phaseEnd).apply()
            scheduleAlarm(app, phaseEnd)
            return
        }

        if (now < phaseEnd - 2_000L) {
            // Henüz bitmedi: alarmı yeniden kur
            scheduleAlarm(app, phaseEnd)
            return
        }

        // Faz zamanı geçmiş: hemen geçiş uygula (catch-up)
        ActionLog.add(app, "döngü", null, true, "Kaçırılan döngü fazı telafi ediliyor")
        advancePhase(app)
    }

    /** Alarm tetiklenince: mevcut fazı bitirip diğerine geç. */
    fun onAlarm(context: Context) {
        val app = context.applicationContext
        if (!isActive(app)) return
        advancePhase(app)
    }

    private fun advancePhase(app: Context) {
        val p = prefs(app)
        if (!p.getBoolean("loopActive", false)) return

        val now = System.currentTimeMillis()
        val cur = p.getString("loopPhase", "on") ?: "on"
        val onM = p.getInt("loopOnMin", 40).coerceIn(5, 120)
        val offM = p.getInt("loopOffMin", 20).coerceIn(5, 120)

        val nextPhase: String
        val nextMs: Long
        val turnOn: Boolean

        if (cur == "on") {
            nextPhase = "off"
            nextMs = offM * 60_000L
            turnOn = false
        } else {
            nextPhase = "on"
            nextMs = minOf(onM * 60_000L, CommandRunner.SAFETY_MS)
            turnOn = true
        }

        val phaseEnd = now + nextMs
        p.edit()
            .putString("loopPhase", nextPhase)
            .putLong("loopPhaseEnd", phaseEnd)
            .apply()

        scheduleAlarm(app, phaseEnd)

        // Komutu gönder (doğrulamalı). ON fazında offAt = phaseEnd.
        val seq = CommandRunner.nextSeq(app)
        CommandWorker.enqueue(app, turnOn, seq, now, "döngü ($nextPhase)", 0, if (turnOn) phaseEnd else 0L)
        ActionLog.add(app, "döngü", turnOn, true, "Faz: $nextPhase (${nextMs / 60_000} dk)")
    }

    private fun scheduleAlarm(app: Context, atMs: Long) {
        try {
            val exact = AlarmUtil.set(app, atMs, pendingIntent(app))
            if (!exact) ActionLog.add(app, "döngü", null, false, "Tam zamanlı alarm izni yok: döngü gecikebilir")
        } catch (e: Exception) {
            ActionLog.add(app, "döngü", null, false, "Döngü alarmı kurulamadı: ${e.message}")
        }
    }

    private fun cancelAlarm(app: Context) {
        try {
            val am = app.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.cancel(pendingIntent(app))
        } catch (_: Exception) {}
    }

    fun statusJson(context: Context): String {
        val p = prefs(context.applicationContext)
        return JSONObject()
            .put("active", p.getBoolean("loopActive", false))
            .put("onMin", p.getInt("loopOnMin", 40))
            .put("offMin", p.getInt("loopOffMin", 20))
            .put("phase", p.getString("loopPhase", "off") ?: "off")
            .put("phaseEnd", p.getLong("loopPhaseEnd", 0L))
            .put("band", p.getInt("loopBand", 1))
            .put("mode", p.getString("loopMode", "day") ?: "day")
            .toString()
    }
}
