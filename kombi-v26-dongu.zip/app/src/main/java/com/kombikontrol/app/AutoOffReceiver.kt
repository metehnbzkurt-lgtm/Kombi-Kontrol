package com.kombikontrol.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Süre sonu / 4 saat güvenlik kapatması. "offAt" tek doğru kaynaktır:
 * eski/iptal edilmiş alarm offAt=0 olduğu için hiçbir şey yapmaz.
 */
class AutoOffReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        // Döngü modu aktifken faz geçişini yalnızca LoopReceiver yönetir
        if (LoopModeManager.isActive(app)) return
        val prefs = app.getSharedPreferences("kombi", Context.MODE_PRIVATE)
        val target = prefs.getLong("offAt", 0L)
        if (target <= 0L) return

        val now = System.currentTimeMillis()
        if (target - now > 5_000L) {
            // Alarm erken geldi (ör. offAt sonradan uzatıldı): gerçek zamana yeniden kur.
            AutoOffScheduler.schedule(app, target)
            return
        }

        // Başarılı kapanma bu alarmı iptal eder; başarısızsa 2 dk sonra tekrar dener (en fazla 10).
        val attempts = prefs.getInt("autoOffAttempts", 0) + 1
        prefs.edit().putInt("autoOffAttempts", attempts).apply()
        if (attempts <= 10) AutoOffScheduler.schedule(app, now + 2 * 60_000L)

        val lateSec = (now - target) / 1000
        ActionLog.add(app, "otomatik kapanma", false, true, "Alarm alındı (gecikme ${lateSec} sn)")
        CommandDispatcher.fromReceiver(app, false, "otomatik kapanma", goAsync())
    }
}
