package com.kombikontrol.app

import android.content.Context

/**
 * Röleye aç/kapat komutunu gönderir ve cihazdan GERİ OKUYARAK doğrular.
 * Sadece doğrulanırsa başarılı sayılır; bu durumda telefon tarafındaki durum
 * (onSince / offAt / kapanma alarmı) da güncellenir.
 *
 * Tüm komutlar tek kilit altında sıralanır; böylece uygulama, alarm ve WorkManager
 * aynı anda komut yarıştırmaz.
 */
object CommandRunner {
    /** Kombi açıkken en fazla çalışma süresi (güvenlik kapatması). */
    const val SAFETY_MS = 4 * 60 * 60 * 1000L

    private val lock = Any()

    class Outcome(val ok: Boolean, val message: String)

    private fun prefs(c: Context) = c.getSharedPreferences("kombi", Context.MODE_PRIVATE)

    /** Yeni bir komut isteği: bekleyen eski yeniden denemeleri geçersiz kılar. */
    fun nextSeq(c: Context): Long = synchronized(lock) {
        val p = prefs(c.applicationContext)
        val s = p.getLong("cmdSeq", 0L) + 1
        p.edit().putLong("cmdSeq", s).apply()
        s
    }

    fun currentSeq(c: Context): Long = prefs(c.applicationContext).getLong("cmdSeq", 0L)

    /**
     * on: istenen durum. fast: alarm anındaki kısa deneme. offAtMs: açılırken kurulacak kapanma anı (0 = varsayılan 4 saat).
     * seq: bu komutun sırası (0 = sıra takibi yok).
     */
    fun run(context: Context, on: Boolean, origin: String, fast: Boolean, offAtMs: Long = 0L, seq: Long = 0L): Outcome {
        val app = context.applicationContext
        synchronized(lock) {
            val outcome = try {
                execute(app, on, fast)
            } catch (e: Exception) {
                Outcome(false, e.message ?: e.javaClass.simpleName)
            }
            if (outcome.ok) {
                applyState(app, on, offAtMs)
                if (seq > 0) prefs(app).edit().putLong("lastOkSeq", seq).apply()
            }
            ActionLog.add(app, origin, on, outcome.ok, outcome.message)
            return outcome
        }
    }

    private fun applyState(app: Context, on: Boolean, offAtMs: Long) {
        val p = prefs(app)
        if (on) {
            val now = System.currentTimeMillis()
            val offAt = if (offAtMs > now) offAtMs else now + SAFETY_MS
            p.edit().putLong("offAt", offAt).putLong("onSince", now).putInt("autoOffAttempts", 0).apply()
            AutoOffScheduler.schedule(app, offAt)
        } else {
            p.edit().putLong("offAt", 0L).putLong("onSince", 0L).putInt("autoOffAttempts", 0).apply()
            AutoOffScheduler.cancel(app)
        }
    }

    private fun execute(app: Context, on: Boolean, fast: Boolean): Outcome {
        val prefs = prefs(app)
        val secure = SecureStore.get(app)

        val deviceId = prefs.getString("deviceId", "") ?: ""
        if (deviceId.isEmpty()) return Outcome(false, "Cihaz ID girilmemiş")
        val outlet = prefs.getInt("outlet", 0)

        val client = EweLinkClient(BuildConfig.EWELINK_APP_ID, BuildConfig.EWELINK_APP_SECRET)
        if (!client.configured) return Outcome(false, "App ID/Secret derlemeye eklenmemiş")
        client.timeoutMs = if (fast) 4000 else 12000
        client.region = prefs.getString("region", "eu") ?: "eu"
        // Her komutta token'ı depodan taze oku (uygulama başka bir yenileme yapmış olabilir).
        client.accessToken = secure.getString("accessToken", null)
        client.refreshToken = secure.getString("refreshToken", null)
        if (client.accessToken == null && client.refreshToken == null) {
            return Outcome(false, "eWeLink oturumu yok: uygulamayı açıp yeniden giriş yap")
        }

        fun persist() {
            secure.edit()
                .putString("accessToken", client.accessToken)
                .putString("refreshToken", client.refreshToken)
                .apply()
            prefs.edit().putString("region", client.region).apply()
        }

        fun <T> auth(block: () -> T): T {
            if (client.accessToken == null) { client.doRefresh(); persist() }
            try {
                return block()
            } catch (e: EweLinkClient.AuthException) {
                try {
                    client.doRefresh(); persist()
                    return block()
                } catch (e2: EweLinkClient.AuthException) {
                    if (fast) throw e2
                    val original = client.region
                    for (r in listOf("as", "eu", "us", "cn")) {
                        if (r == original) continue
                        client.region = r
                        try {
                            val v = block(); persist(); return v
                        } catch (_: EweLinkClient.AuthException) {
                        }
                    }
                    client.region = original
                    throw e2
                }
            }
        }

        // 1) komut
        auth { client.setSwitch(deviceId, outlet, on) }

        // 2) doğrulama: cihazın bildirdiği röle durumu istenenle aynı mı?
        val tries = if (fast) 2 else 4
        var state: Boolean? = null
        for (i in 0 until tries) {
            Thread.sleep(if (i == 0) 400L else 800L)
            state = try { auth { client.getSwitch(deviceId, outlet) } } catch (_: Exception) { null }
            if (state == on) break
        }
        return when (state) {
            on -> Outcome(true, "Röle ${if (on) "açık" else "kapalı"} (doğrulandı)")
            null -> Outcome(false, "Komut gönderildi ama röle durumu okunamadı")
            else -> Outcome(false, "Komut kabul edildi ama röle ${if (state == true) "açık" else "kapalı"} kaldı (cihaz çevrimdışı olabilir)")
        }
    }
}
