package com.kombikontrol.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.util.concurrent.Executors

/**
 * ScheduleAlarmManager'ın kurduğu günlük/haftalık zamanlama alarmı tetiklenince
 * çalışır: komutu gönderir, sonra aynı kaydı bir sonraki uygun zamana yeniden kurar.
 * Ses/titreşim/ekran YOK.
 */
class ScheduleReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val appContext = context.applicationContext
        val scheduleId = intent.getLongExtra("scheduleId", -1L)
        val on = intent.getBooleanExtra("on", true)
        val pending = goAsync()
        Executors.newSingleThreadExecutor().execute {
            var waitingForSpeech = false
            try {
                if (AutoOffWorker.setSwitch(appContext, on)) {
                    waitingForSpeech = true
                    VoiceAnnouncer.announce(appContext, on) { pending.finish() }
                }
            } catch (e: Exception) {
                // Sessiz başarısızlık: bir sonraki tetiklenmede tekrar denenecek.
            } finally {
                if (scheduleId >= 0) ScheduleAlarmManager.rescheduleAfterFire(appContext, scheduleId)
                if (!waitingForSpeech) pending.finish()
            }
        }
    }
}
