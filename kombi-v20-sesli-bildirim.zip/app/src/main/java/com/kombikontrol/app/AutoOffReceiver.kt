package com.kombikontrol.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.util.concurrent.Executors

/**
 * Kapanma alarmı tetiklendiğinde röleye OFF komutu gönderir.
 * Ağ/eWeLink geçici hatalarında kapanma kaydı silinmez; yeniden denenir.
 */
class AutoOffReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val appContext = context.applicationContext
        val pending = goAsync()
        Executors.newSingleThreadExecutor().execute {
            var waitingForSpeech = false
            try {
                val prefs = appContext.getSharedPreferences("kombi", Context.MODE_PRIVATE)
                val target = prefs.getLong("offAt", 0L)
                // Eski/iptal edilmiş alarm ise hiçbir işlem yapma.
                if (target > 0L && target <= System.currentTimeMillis()) {
                    val closed = try { AutoOffWorker.turnOff(appContext) } catch (_: Exception) { false }
                    if (closed) {
                        waitingForSpeech = true
                        VoiceAnnouncer.announce(appContext, false) { pending.finish() }
                    } else {
                        val attempts = prefs.getInt("autoOffAttempts", 0) + 1
                        prefs.edit().putInt("autoOffAttempts", attempts).apply()
                        // İlk alarm başarısızsa 2 dakika sonra tekrar dene (en fazla 5 kez).
                        if (attempts <= 5) {
                            AutoOffScheduler.schedule(appContext, System.currentTimeMillis() + 2 * 60_000L)
                        }
                    }
                }
            } finally {
                if (!waitingForSpeech) pending.finish()
            }
        }
    }
}
