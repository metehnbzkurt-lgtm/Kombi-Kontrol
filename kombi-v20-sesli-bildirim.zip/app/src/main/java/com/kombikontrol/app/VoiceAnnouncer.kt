package com.kombikontrol.app

import android.content.Context
import android.media.AudioAttributes
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.UUID

/** Türkçe sesli çalışma/durma duyuruları. Uygulama arka plandayken de çağrılabilir. */
object VoiceAnnouncer {
    fun announce(context: Context, isOn: Boolean, onFinished: () -> Unit = {}) {
        val app = context.applicationContext
        val phrase = if (isOn) "Kombi çalışmaya başladı." else "Kombi durduruldu."
        try {
            lateinit var tts: TextToSpeech
            tts = TextToSpeech(app) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    val locale = Locale("tr", "TR")
                    val lang = tts.setLanguage(locale)
                    if (lang != TextToSpeech.LANG_MISSING_DATA && lang != TextToSpeech.LANG_NOT_SUPPORTED) {
                        tts.setAudioAttributes(
                            AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                                .build()
                        )
                        tts.setSpeechRate(0.92f)
                        tts.setPitch(1.0f)
                        val id = UUID.randomUUID().toString()
                        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                            override fun onStart(utteranceId: String?) {}
                            override fun onDone(utteranceId: String?) { tts.shutdown(); onFinished() }
                            @Deprecated("Deprecated in Java")
                            override fun onError(utteranceId: String?) { tts.shutdown(); onFinished() }
                            override fun onError(utteranceId: String?, errorCode: Int) { tts.shutdown(); onFinished() }
                        })
                        tts.speak(phrase, TextToSpeech.QUEUE_FLUSH, null, id)
                    } else { tts.shutdown(); onFinished() }
                } else { tts.shutdown(); onFinished() }
            }
        } catch (_: Exception) {
            onFinished()
            // TTS motoru veya Türkçe ses paketi yoksa uygulamanın kontrol işlevi etkilenmez.
        }
    }
}
