# Kombi Kontrol V13 (Android)

HTML arayüz (`app/src/main/assets/index.html`) bir WebView içinde açılır; Kotlin tarafı eWeLink ile konuşur.

## Derleme (GitHub) — mobilde kolay yol
1. Bu projenin **zip dosyasının kendisini** (açmadan) repo'nun **ana dizinine** yükle (Add file > Upload files).
   Workflow artık zip'i kendisi otomatik açıyor, tek tek dosya yüklemene gerek yok.
2. Repo'da eskiden kalan karışık klasörler varsa (örn. "proje") onları sil, kafa karıştırmasın.
3. Repo > Settings > Secrets and variables > Actions: `EWELINK_APP_ID` ve `EWELINK_APP_SECRET` ekle (Developer onayı gelince).
4. Actions > Build APK > Run workflow. Bitince **KombiKontrol-APK** çıktısından `app-debug.apk` indir.

`.github/workflows/build.yml` zip içinde geliyor, zip'i yükleyince o da otomatik repo'ya girer —
ayrıca elle oluşturmana gerek yok.

### Alternatif: dosyaları tek tek açıp yüklemek istersen
Zip'i açtıktan sonra içindeki **her şeyi** (gizli `.github` klasörü dahil) repo'nun ana dizinine,
klasör yapısını bozmadan yükle. `settings.gradle.kts` dosyası repo kökünde (alt klasörde değil)
olmalı — "Build Debug APK" adımı tam da onu arıyor.

## Uygulamada
Ayarlar (⚙️) > Bölge ve Cihaz ID'yi gir, "Kaydet" de. Sonra "eWeLink ile Oturum Aç" butonuna bas:
telefonun kendi tarayıcısında eWeLink'in **kendi** giriş sayfası açılır, e-posta/şifreni orada girersin.
Uygulama şifreni hiç görmez, hiç saklamaz — sadece eWeLink'in döndüğü geçici token'ı (Android Keystore
ile şifrelenmiş olarak) saklar.

Zamanlamalar, geri sayım ve 4 saat güvenlik kapatması cihaza yazılır; uygulama kapalıyken de çalışır.

## Güvenlik notu
- E-posta/şifre bu uygulamanın hiçbir dosyasında, hiçbir satırında yok.
- Giriş eWeLink'in resmi OAuth2.0 sayfasında yapılır (c2ccdn.coolkit.cc).
- Dönen token `EncryptedSharedPreferences` (Android Keystore donanım şifrelemesi) ile saklanır.

## Not
eWeLink/OAuth bölümü (EweLinkClient.kt / KombiBridge.kt) Developer onayı olmadan test edilemedi,
özellikle imzalama (sign) adımı. Hata olursa mesaj uygulamada görünür; onay gelince birlikte
test edip gerekirse düzelteceğiz.


## V13 değişiklikleri
- MINI-D için otomatik kapanma Pulse/Inching komutuna bağlanmaz; eWeLink `delay` timer kullanılır.
- Geri sayım zamanlayıcısına resmi API biçimindeki `period` (dakika) alanı eklenmiştir.
- Günlük tekrar zamanlayıcıları cihazın UTC cron biçimine dönüştürülür.
- `timersUnsupported` kalıcı engeli kaldırılmıştır; sonraki denemeler yeniden yapılır.
- eWeLink'in tam timer listesi gönderilir; uygulamanın sahip olmadığı mevcut timer'lar korunur.
- Yazma işleminden sonra timer listesi yeniden okunur; cihazdan doğrulanmadan başarı mesajı gösterilmez.
- Manuel açma/kapatma röle komutu korunmuştur; zamanlayıcı hatası ayrı raporlanır.

Not: eWeLink cihaz başına en fazla 8 etkin timer desteklediğini bildirir. Cihaz/firmware'in timer yazma yetkisi ve gerçek çalışma davranışı fiziksel cihaz üzerinde test edilmelidir.


## V20 sesli bildirimler

- Röleye açma/kapatma komutu başarıyla gönderildiğinde Türkçe sesli duyuru yapılır.
- Süre sonunda otomatik kapanma ve günlük/haftalık zamanlamalar da sesli duyuru yapar.
- Duyurular Android metin-konuşma (TTS) motorunu kullanır; Türkçe ses paketi kurulu olmalıdır.
- Telefon sessizde/DND modunda veya medya/bildirim sesi kapalıysa duyuru duyulmayabilir.
