package com.kombikontrol.app

import android.content.Context
import android.content.SharedPreferences

/**
 * AlarmManager tetiklendiğinde (uygulama kapalı/arka planda olsa bile) kombiyi
 * kapatan, Activity/WebView'e ihtiyaç duymayan bağımsız mantık.
 * KombiBridge'deki giriş/bölge deneme mantığının sadeleştirilmiş halidir.
 */
object AutoOffWorker {

    fun turnOff(context: Context) {
        val prefs = context.getSharedPreferences("kombi", Context.MODE_PRIVATE)
        val secure = SecureStore.get(context)

        val deviceId = prefs.getString("deviceId", "") ?: ""
        if (deviceId.isEmpty()) return
        val outlet = prefs.getInt("outlet", 0)

        val client = EweLinkClient(BuildConfig.EWELINK_APP_ID, BuildConfig.EWELINK_APP_SECRET)
        if (!client.configured) return
        client.region = prefs.getString("region", "eu") ?: "eu"
        client.accessToken = secure.getString("accessToken", null)
        client.refreshToken = secure.getString("refreshToken", null)
        if (client.accessToken == null && client.refreshToken == null) return

        fun persistTokens() {
            secure.edit()
                .putString("accessToken", client.accessToken)
                .putString("refreshToken", client.refreshToken)
                .apply()
            prefs.edit().putString("region", client.region).apply()
        }

        fun tryOff(): Boolean = try {
            client.setSwitch(deviceId, outlet, false)
            true
        } catch (e: EweLinkClient.AuthException) {
            false
        }

        // Giriş yoksa (accessToken boş) önce yenile.
        if (client.accessToken == null) {
            try { client.doRefresh() } catch (e: Exception) { return }
        }

        if (tryOff()) {
            persistTokens()
            markDone(prefs)
            return
        }

        // Token süresi dolmuş olabilir: yenile ve tekrar dene.
        try {
            client.doRefresh()
            if (tryOff()) {
                persistTokens()
                markDone(prefs)
                return
            }
        } catch (e: Exception) {
            // yenileme olmadı, bölge denemesine geç
        }

        // Belki token başka bölgede geçerli: diğer bölgeleri dene.
        val original = client.region
        for (r in listOf("as", "eu", "us", "cn")) {
            if (r == original) continue
            client.region = r
            if (tryOff()) {
                persistTokens()
                markDone(prefs)
                return
            }
        }
        client.region = original
        // Başarısız: bir sonraki uygulama açılışında kullanıcı gerçek durumu görecek
        // (getStatus cihazdan okur), burada sessizce bırakıyoruz.
    }

    private fun markDone(prefs: SharedPreferences) {
        prefs.edit().putLong("offAt", 0L).apply()
    }
}
